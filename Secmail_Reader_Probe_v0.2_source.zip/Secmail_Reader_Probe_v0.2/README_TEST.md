# Secmail Assistant v0.2

## Confirmed target
- Secmail package observed on device: `com.uusafe.secmail`

## v0.2 changes
- App launcher icon applied.
- Keeps the same applicationId: `com.mintomax.secmailprobe`.
- Uses `com.uusafe.secmail` as the default target and never targets itself.
- Reads the currently opened Secmail message from Accessibility UI nodes.
- Extracts Subject / Sender / To / Date / Body from observed Secmail view IDs and WebView body nodes.
- Shows a readable mail card instead of only a raw UI-tree dump.
- Local rule-based extraction for Key Points / Action / Schedule. No AI and no network permission.
- Manual `Save` stores the current message in an app-private SQLite database.
- Raw Accessibility UI tree remains available only under Debug.
- No auto-click, no auto-scroll, no OCR, no mail-server connection, no external transmission.

## Test flow
1. Install v0.2. Because the GitHub Actions build is still debug-signed, uninstalling the previous build may be required once.
2. Enable Secmail Assistant under Android Accessibility.
3. Tap `Secmail 열기`.
4. Open one mail in Secmail.
5. Return to Secmail Assistant.
6. Confirm Subject / From / To / Date / Body and the local Important Info card.
7. Use `저장` only for messages you intend to keep locally.

## Not implemented yet
- Automatic inbox traversal or automatic clicking/scrolling.
- Sent-folder traversal.
- Background reading.
- AI/ChatGPT transmission or cloud summarization.
- Silent self-update.
