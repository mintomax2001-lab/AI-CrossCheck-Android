package com.mintomax.secmailprobe;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class ProbeAccessibilityService extends AccessibilityService {

    public static final String PREFS = "probe_prefs";
    public static final String DEFAULT_TARGET = "com.uusafe.secmail";
    public static final String KEY_TARGET = "target_pkg";
    public static final String KEY_CAPTURE = "last_capture";
    public static final String KEY_CAPTURE_PKG = "last_capture_pkg";
    public static final String KEY_CAPTURE_TIME = "last_capture_time";
    public static final String KEY_NODE_COUNT = "last_node_count";
    public static final String KEY_EVENT = "last_event";
    public static final String KEY_SUBJECT = "mail_subject";
    public static final String KEY_SENDER = "mail_sender";
    public static final String KEY_RECIPIENTS = "mail_recipients";
    public static final String KEY_MAIL_DATE = "mail_date";
    public static final String KEY_BODY = "mail_body";

    private static final int MAX_NODES = 800;
    private static final int MAX_CHARS = 220000;
    private long lastCaptureElapsed = 0L;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        if (!isTargetPackage(pkg)) return;

        long now = SystemClock.elapsedRealtime();
        if (now - lastCaptureElapsed < 350L) return;
        lastCaptureElapsed = now;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        StringBuilder out = new StringBuilder();
        int[] count = new int[]{0};
        walk(root, out, 0, count);

        MailSnapshot mail = extractMail(root);
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault()).format(new Date());
        mail.capturedAt = timestamp;
        mail.packageName = pkg;

        SharedPreferences.Editor e = getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_CAPTURE, out.toString())
                .putString(KEY_CAPTURE_PKG, pkg)
                .putString(KEY_CAPTURE_TIME, timestamp)
                .putInt(KEY_NODE_COUNT, count[0])
                .putString(KEY_EVENT, AccessibilityEvent.eventTypeToString(event.getEventType()));

        if (mail.hasMailContent()) {
            e.putString(KEY_SUBJECT, mail.subject)
                    .putString(KEY_SENDER, mail.sender)
                    .putString(KEY_RECIPIENTS, mail.recipients)
                    .putString(KEY_MAIL_DATE, mail.mailDate)
                    .putString(KEY_BODY, mail.body);
        }
        e.apply();
    }

    private MailSnapshot extractMail(AccessibilityNodeInfo root) {
        MailSnapshot m = new MailSnapshot();
        m.subject = firstTextById(root, DEFAULT_TARGET + ":id/mail_subject_textview");
        m.recipients = firstTextById(root, DEFAULT_TARGET + ":id/to_area_general_tv");
        m.mailDate = firstTextById(root, DEFAULT_TARGET + ":id/mail_date_textview");
        m.sender = findSender(root);

        AccessibilityNodeInfo bodyNode = findByIdRecursive(root, "main-body");
        if (bodyNode == null) bodyNode = findByIdRecursive(root, "mailContentContainer");
        if (bodyNode == null) bodyNode = findByIdRecursive(root, "contentDiv");
        if (bodyNode != null) m.body = collectUsefulText(bodyNode);
        return m;
    }

    private String firstTextById(AccessibilityNodeInfo root, String id) {
        try {
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(id);
            if (nodes != null) {
                for (AccessibilityNodeInfo n : nodes) {
                    String t = safe(n.getText()).trim();
                    if (!t.isEmpty()) return t;
                }
            }
        } catch (Exception ignored) {}
        AccessibilityNodeInfo n = findByIdRecursive(root, id);
        return n == null ? "" : safe(n.getText()).trim();
    }

    private String findSender(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo label = findByIdRecursive(root, DEFAULT_TARGET + ":id/mail_sender_name_tv");
        if (label == null) return "";
        AccessibilityNodeInfo parent = label.getParent();
        if (parent == null) return "";
        boolean afterLabel = false;
        for (int i = 0; i < parent.getChildCount(); i++) {
            AccessibilityNodeInfo c = parent.getChild(i);
            if (c == null) continue;
            if (sameNode(c, label)) {
                afterLabel = true;
                continue;
            }
            if (!afterLabel) continue;
            String id = safe(c.getViewIdResourceName());
            String t = safe(c.getText()).trim();
            if (t.isEmpty()) continue;
            if (id.endsWith("mail_date_textview") || id.endsWith("to_area_general_tv")) continue;
            if (t.equals("발신") || t.equals("발신 ")) continue;
            return t;
        }
        return "";
    }

    private boolean sameNode(AccessibilityNodeInfo a, AccessibilityNodeInfo b) {
        return a.equals(b);
    }

    private AccessibilityNodeInfo findByIdRecursive(AccessibilityNodeInfo node, String wanted) {
        if (node == null) return null;
        String id = safe(node.getViewIdResourceName());
        if (id.equals(wanted) || id.endsWith(":" + wanted) || id.endsWith("/" + wanted)) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo found = findByIdRecursive(node.getChild(i), wanted);
            if (found != null) return found;
        }
        return null;
    }

    private String collectUsefulText(AccessibilityNodeInfo node) {
        Set<String> ordered = new LinkedHashSet<>();
        collectText(node, ordered);
        StringBuilder b = new StringBuilder();
        for (String s : ordered) {
            String x = s.replace('\u00A0', ' ').replace("\\n", "\n").trim();
            if (x.isEmpty()) continue;
            if (b.length() > 0) b.append('\n');
            b.append(x);
        }
        return b.toString().trim();
    }

    private void collectText(AccessibilityNodeInfo node, Set<String> out) {
        if (node == null) return;
        String t = safe(node.getText()).trim();
        if (!t.isEmpty() && node.getChildCount() == 0) out.add(t);
        for (int i = 0; i < node.getChildCount(); i++) collectText(node.getChild(i), out);
    }

    private boolean isTargetPackage(String pkg) {
        if (getPackageName().equals(pkg)) return false;
        SharedPreferences p = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String target = p.getString(KEY_TARGET, DEFAULT_TARGET);
        if (target != null && !target.trim().isEmpty()) return target.trim().equals(pkg);
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            String label = pm.getApplicationLabel(ai).toString();
            return label.toLowerCase(Locale.ROOT).contains("secmail");
        } catch (Exception ignored) {
            return false;
        }
    }

    private void walk(AccessibilityNodeInfo node, StringBuilder out, int depth, int[] count) {
        if (node == null || count[0] >= MAX_NODES || out.length() >= MAX_CHARS) return;
        count[0]++;
        String text = safe(node.getText());
        String desc = safe(node.getContentDescription());
        String cls = safe(node.getClassName());
        String id = safe(node.getViewIdResourceName());
        out.append('[').append(count[0]).append("] depth=").append(depth)
                .append(" class=").append(cls)
                .append(" id=").append(id)
                .append(" clickable=").append(node.isClickable())
                .append(" scrollable=").append(node.isScrollable())
                .append(" enabled=").append(node.isEnabled());
        if (!text.isEmpty()) out.append(" text=\"").append(clean(text)).append('"');
        if (!desc.isEmpty()) out.append(" desc=\"").append(clean(desc)).append('"');
        out.append('\n');
        for (int i = 0; i < node.getChildCount(); i++) {
            if (count[0] >= MAX_NODES || out.length() >= MAX_CHARS) break;
            walk(node.getChild(i), out, depth + 1, count);
        }
    }

    private String safe(CharSequence s) { return s == null ? "" : s.toString(); }
    private String clean(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", " ").replace("\n", "\\n");
    }

    @Override
    public void onInterrupt() {}
}
