package com.mintomax.secmailprobe;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ImportantInfoExtractor {
    private ImportantInfoExtractor() {}

    public static class Result {
        public final List<String> keyPoints = new ArrayList<>();
        public final List<String> actions = new ArrayList<>();
        public final List<String> schedules = new ArrayList<>();
    }

    private static final Pattern[] DATE_PATTERNS = new Pattern[]{
            Pattern.compile("\\b\\d{1,2}/\\d{1,2}\\s*(?:~|–|-)\\s*\\d{1,2}/\\d{1,2}\\b"),
            Pattern.compile("\\b20\\d{2}[./-]\\d{1,2}[./-]\\d{1,2}\\b"),
            Pattern.compile("\\b\\d{1,2}월\\s*\\d{1,2}일\\b"),
            Pattern.compile("\\b\\d{1,2}:\\d{2}\\b")
    };

    private static final String[] ACTION_WORDS = new String[]{
            "요청", "부탁", "바랍니다", "필요", "검토", "확인", "회신", "선정", "잡아", "진행", "방문", "미팅", "일정",
            "please", "request", "need", "review", "confirm", "schedule", "visit", "meeting",
            "请", "需要", "确认", "安排", "访问", "会议"
    };

    public static Result extract(String subject, String body) {
        Result r = new Result();
        String normalized = body == null ? "" : body.replace('\u00A0', ' ').replace("\\n", "\n").trim();
        List<String> sentences = splitSentences(normalized);

        Set<String> scheduleSet = new LinkedHashSet<>();
        for (Pattern p : DATE_PATTERNS) {
            Matcher m = p.matcher(normalized);
            while (m.find() && scheduleSet.size() < 6) scheduleSet.add(clean(m.group()));
        }
        r.schedules.addAll(scheduleSet);

        Set<String> actions = new LinkedHashSet<>();
        for (String s : sentences) {
            String low = s.toLowerCase(Locale.ROOT);
            for (String word : ACTION_WORDS) {
                if (low.contains(word.toLowerCase(Locale.ROOT))) {
                    if (!isNoise(s)) actions.add(trimForCard(s, 140));
                    break;
                }
            }
            if (actions.size() >= 4) break;
        }
        r.actions.addAll(actions);

        Set<String> keys = new LinkedHashSet<>();
        if (subject != null && !subject.trim().isEmpty()) keys.add(trimForCard(subject.trim(), 120));
        for (String s : sentences) {
            if (isNoise(s)) continue;
            boolean useful = containsDate(s) || containsActionWord(s) || s.length() >= 18;
            if (useful) keys.add(trimForCard(s, 140));
            if (keys.size() >= 4) break;
        }
        r.keyPoints.addAll(keys);
        return r;
    }

    private static boolean containsDate(String s) {
        for (Pattern p : DATE_PATTERNS) if (p.matcher(s).find()) return true;
        return false;
    }

    private static boolean containsActionWord(String s) {
        String low = s.toLowerCase(Locale.ROOT);
        for (String w : ACTION_WORDS) if (low.contains(w.toLowerCase(Locale.ROOT))) return true;
        return false;
    }

    private static List<String> splitSentences(String body) {
        List<String> out = new ArrayList<>();
        if (body == null || body.trim().isEmpty()) return out;
        String[] chunks = body.split("(?<=[.!?。！？])\\s+|\\n+");
        for (String c : chunks) {
            String x = clean(c);
            if (!x.isEmpty()) out.add(x);
        }
        return out;
    }

    private static boolean isNoise(String s) {
        String x = clean(s);
        if (x.isEmpty()) return true;
        String low = x.toLowerCase(Locale.ROOT);
        return low.equals("안녕하세요.") || low.equals("안녕하세요") || low.equals("감사합니다.") || low.equals("감사합니다") ||
                low.equals("thanks") || low.equals("thank you") || x.length() <= 2;
    }

    private static String clean(String s) {
        if (s == null) return "";
        return s.replace('\u00A0', ' ').replaceAll("\\s+", " ").trim();
    }

    private static String trimForCard(String s, int max) {
        String x = clean(s);
        return x.length() <= max ? x : x.substring(0, max - 1) + "…";
    }
}
