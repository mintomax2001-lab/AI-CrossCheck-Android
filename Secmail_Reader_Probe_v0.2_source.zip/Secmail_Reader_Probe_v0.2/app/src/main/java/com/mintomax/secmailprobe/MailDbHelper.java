package com.mintomax.secmailprobe;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class MailDbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "secmail_assistant.db";
    private static final int DB_VERSION = 1;

    public MailDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE saved_mail (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "subject TEXT, sender TEXT, recipients TEXT, mail_date TEXT, body TEXT," +
                "captured_at TEXT, package_name TEXT, key_points TEXT, actions TEXT, schedules TEXT," +
                "saved_at INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    public long save(MailSnapshot m, ImportantInfoExtractor.Result info) {
        ContentValues cv = new ContentValues();
        cv.put("subject", m.subject);
        cv.put("sender", m.sender);
        cv.put("recipients", m.recipients);
        cv.put("mail_date", m.mailDate);
        cv.put("body", m.body);
        cv.put("captured_at", m.capturedAt);
        cv.put("package_name", m.packageName);
        cv.put("key_points", join(info.keyPoints));
        cv.put("actions", join(info.actions));
        cv.put("schedules", join(info.schedules));
        cv.put("saved_at", System.currentTimeMillis());
        return getWritableDatabase().insert("saved_mail", null, cv);
    }

    public int count() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM saved_mail", null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    private String join(java.util.List<String> list) {
        StringBuilder b = new StringBuilder();
        for (String s : list) {
            if (b.length() > 0) b.append("\n");
            b.append(s);
        }
        return b.toString();
    }
}
