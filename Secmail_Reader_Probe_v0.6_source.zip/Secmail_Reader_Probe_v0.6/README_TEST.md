# Secmail Assistant v0.6 — Test Notes

## What changed

### 1) Two-stage Inbox sync
- `Inbox 동기화` first scans the accessible Inbox list to estimate:
  - Inbox rows seen
  - rows already processed by Secmail Assistant
  - rows that still need collection
- Then it rewinds toward the top of the scanned range and starts collection.
- Read/unread state is **not** used as the collection criterion.

### 2) Accessibility progress overlay
While Secmail is foreground, a small top overlay shows:
- `Inbox 탐색 중` during discovery
- `수집 n / N` during collection
- Inbox rows seen / target count / new saves / current truncated preview
- `중지` button

The overlay uses `TYPE_ACCESSIBILITY_OVERLAY`; it does not require a separate “draw over other apps” permission.

### 3) Automatic foreign-language translation
- New optional auto-translation toggle, ON by default.
- Detects source language from the **latest message** and translates foreign language to Korean.
- English and Chinese are the primary pre-download targets; ML Kit supports additional languages.
- Original body remains unchanged and remains the source for fingerprinting, workflow classification and GPT review.
- Saved-mail cards and the loaded-mail view show Korean machine translation when available.
- Search also includes translated text.
- Existing older saved mails are translated when opened if auto translation is ON.

### 4) Translation privacy / network boundary
- Translation uses Google ML Kit on-device Translation.
- Mail input text and translated output are processed on-device by ML Kit.
- Network may be used to download/update language models and for ML Kit SDK diagnostics/metrics.
- This build therefore declares `INTERNET`; it still does not directly connect to the corporate mail server.
- Translation is marked as automatic Google Translate output and should be treated as reference only for technical terminology.

## Device test checklist
1. Install v0.6 over the stable-signed v0.5 build after stable signing.
2. Confirm Accessibility remains enabled after normal overwrite update.
3. Press `Inbox 동기화`.
4. Confirm Secmail comes foreground and overlay appears.
5. Confirm discovery shows Inbox count and collection target count.
6. Confirm collection changes to `n / N` and current mail preview changes.
7. Confirm `중지` stops the run.
8. Confirm finish summary remains in Secmail Assistant when returning.
9. Save/open an English mail; confirm Korean translation appears after model download.
10. Save/open a Chinese mail; confirm Korean translation appears.
11. Confirm original mail remains unchanged.
12. Test `영/중 모델 준비` once on a network connection.
13. Confirm Action Inbox search finds words that exist only in the translated body.

## Known limits
- Exact Secmail Inbox row structure is still device/app-version dependent. v0.6 keeps conservative row scoring and detail-screen guards.
- Discovery count covers the scanned range (max 10 list-scroll segments), not an unlimited mailbox.
- Accessibility UI automation requires Secmail to be foreground; the overlay is the visibility layer rather than pretending collection is fully background.
- ML Kit on-device translation is intended for casual/simple translation. Technical mail terms, abbreviations, voltages and process names must be checked against the original.
- Chinese → Korean may have lower fidelity because ML Kit non-English pairs can use English as an intermediate representation.
- If language models cannot be downloaded in the current network environment, original mail collection still works; GPT Review remains a separate explicit-share path.

## Post-collection workflow revision
v0.6 now treats collection as the start of a workflow, not the endpoint.

- Automatic app work after capture: latest-message extraction → optional Korean translation → local importance/workflow/topic classification → Action candidate extraction.
- Completion overlay shows: new saved / reply / action / schedule / FYI counts.
- Completion overlay keeps a user-tappable `Action Inbox` / `결과 보기` CTA before it disappears.
- Main screen adds `수집 후 처리` card with a recommended processing order.
- Each saved mail card now shows an explicit `다음 행동` sentence.
- Reply candidates use `회신 준비` as the primary AI-review CTA.
- User remains responsible for external decisions/sending. After sending a reply, set the item to `대기 중`; Sent-folder based automatic waiting detection is a later feature.
