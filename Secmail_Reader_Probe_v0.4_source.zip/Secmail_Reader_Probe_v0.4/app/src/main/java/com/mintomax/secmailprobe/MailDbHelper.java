package com.mintomax.secmailprobe;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MailDbHelper extends SQLiteOpenHelper {
    private static final String DB_NAME = "secmail_assistant.db";
    private static final int DB_VERSION = 2;

    public static class SaveResult {
        public final long id;
        public final boolean inserted;
        public final boolean duplicate;
        SaveResult(long id, boolean inserted, boolean duplicate) {
            this.id = id;
            this.inserted = inserted;
            this.duplicate = duplicate;
        }
    }

    public MailDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE saved_mail (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "subject TEXT, sender TEXT, recipients TEXT, mail_date TEXT, body TEXT," +
                "captured_at TEXT, package_name TEXT, key_points TEXT, actions TEXT, schedules TEXT," +
                "importance INTEGER NOT NULL DEFAULT 0, has_action INTEGER NOT NULL DEFAULT 0," +
                "has_schedule INTEGER NOT NULL DEFAULT 0, fingerprint TEXT UNIQUE," +
                "saved_at INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX idx_saved_mail_saved_at ON saved_mail(saved_at DESC)");
        db.execSQL("CREATE INDEX idx_saved_mail_importance ON saved_mail(importance DESC)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            safeExec(db, "ALTER TABLE saved_mail ADD COLUMN importance INTEGER NOT NULL DEFAULT 0");
            safeExec(db, "ALTER TABLE saved_mail ADD COLUMN has_action INTEGER NOT NULL DEFAULT 0");
            safeExec(db, "ALTER TABLE saved_mail ADD COLUMN has_schedule INTEGER NOT NULL DEFAULT 0");
            safeExec(db, "ALTER TABLE saved_mail ADD COLUMN fingerprint TEXT");
            safeExec(db, "CREATE UNIQUE INDEX IF NOT EXISTS idx_saved_mail_fingerprint ON saved_mail(fingerprint)");
            safeExec(db, "CREATE INDEX IF NOT EXISTS idx_saved_mail_saved_at ON saved_mail(saved_at DESC)");
            safeExec(db, "CREATE INDEX IF NOT EXISTS idx_saved_mail_importance ON saved_mail(importance DESC)");
            backfillV2(db);
        }
    }

    private void safeExec(SQLiteDatabase db, String sql) {
        try { db.execSQL(sql); } catch (Exception ignored) {}
    }

    private void backfillV2(SQLiteDatabase db) {
        try (Cursor c = db.rawQuery("SELECT id,subject,sender,recipients,mail_date,body,captured_at,package_name FROM saved_mail", null)) {
            while (c.moveToNext()) {
                MailSnapshot m = new MailSnapshot();
                long id = c.getLong(0);
                m.subject = nz(c.getString(1));
                m.sender = nz(c.getString(2));
                m.recipients = nz(c.getString(3));
                m.mailDate = nz(c.getString(4));
                m.body = nz(c.getString(5));
                m.capturedAt = nz(c.getString(6));
                m.packageName = nz(c.getString(7));
                ImportantInfoExtractor.Result info = ImportantInfoExtractor.extract(m.subject, m.body);
                ContentValues cv = new ContentValues();
                cv.put("fingerprint", fingerprintFor(m));
                cv.put("importance", info.importanceScore);
                cv.put("has_action", info.actions.isEmpty() ? 0 : 1);
                cv.put("has_schedule", info.schedules.isEmpty() ? 0 : 1);
                cv.put("key_points", join(info.keyPoints));
                cv.put("actions", join(info.actions));
                cv.put("schedules", join(info.schedules));
                db.update("saved_mail", cv, "id=?", new String[]{String.valueOf(id)});
            }
        } catch (Exception ignored) {}
    }

    public SaveResult saveIfNew(MailSnapshot m, ImportantInfoExtractor.Result info) {
        if (m == null || !m.hasMailContent()) return new SaveResult(-1, false, false);
        String fp = fingerprintFor(m);
        long existing = findIdByFingerprint(fp);
        if (existing > 0) return new SaveResult(existing, false, true);

        ContentValues cv = new ContentValues();
        cv.put("subject", m.subject);
        cv.put("sender", m.sender);
        cv.put("recipients", m.recipients);
        cv.put("mail_date", m.mailDate);
        cv.put("body", m.body);
        cv.put("captured_at", m.capturedAt);
        cv.put("package_name", m.packageName);
        cv.put("key_points", join(info.keyPoints));
        cv.put("actions", join(info.actions));
        cv.put("schedules", join(info.schedules));
        cv.put("importance", info.importanceScore);
        cv.put("has_action", info.actions.isEmpty() ? 0 : 1);
        cv.put("has_schedule", info.schedules.isEmpty() ? 0 : 1);
        cv.put("fingerprint", fp);
        cv.put("saved_at", System.currentTimeMillis());
        long id = getWritableDatabase().insertWithOnConflict("saved_mail", null, cv, SQLiteDatabase.CONFLICT_IGNORE);
        if (id > 0) return new SaveResult(id, true, false);
        existing = findIdByFingerprint(fp);
        return new SaveResult(existing, false, existing > 0);
    }

    public long save(MailSnapshot m, ImportantInfoExtractor.Result info) {
        return saveIfNew(m, info).id;
    }

    public int deleteById(long id) {
        return getWritableDatabase().delete("saved_mail", "id=?", new String[]{String.valueOf(id)});
    }

    public int deleteAll() {
        return getWritableDatabase().delete("saved_mail", null, null);
    }

    public int count() { return countFilter("all"); }

    public int countFilter(String filter) {
        String where = whereFor(filter);
        String sql = "SELECT COUNT(*) FROM saved_mail" + (where.isEmpty() ? "" : " WHERE " + where);
        try (Cursor c = getReadableDatabase().rawQuery(sql, null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    public List<SavedMailRecord> list(String filter, int limit) {
        List<SavedMailRecord> out = new ArrayList<>();
        String where = whereFor(filter);
        String sql = "SELECT id,subject,sender,recipients,mail_date,body,captured_at,package_name,key_points,actions,schedules," +
                "importance,saved_at,fingerprint FROM saved_mail" + (where.isEmpty() ? "" : " WHERE " + where) +
                " ORDER BY saved_at DESC LIMIT " + Math.max(1, Math.min(limit, 200));
        try (Cursor c = getReadableDatabase().rawQuery(sql, null)) {
            while (c.moveToNext()) {
                SavedMailRecord r = new SavedMailRecord();
                r.id = c.getLong(0);
                r.subject = nz(c.getString(1));
                r.sender = nz(c.getString(2));
                r.recipients = nz(c.getString(3));
                r.mailDate = nz(c.getString(4));
                r.body = nz(c.getString(5));
                r.capturedAt = nz(c.getString(6));
                r.packageName = nz(c.getString(7));
                r.keyPoints = nz(c.getString(8));
                r.actions = nz(c.getString(9));
                r.schedules = nz(c.getString(10));
                r.importance = c.getInt(11);
                r.savedAt = c.getLong(12);
                r.fingerprint = nz(c.getString(13));
                out.add(r);
            }
        }
        return out;
    }

    private String whereFor(String filter) {
        if (filter == null) return "";
        switch (filter.toLowerCase(Locale.ROOT)) {
            case "important": return "importance >= 3";
            case "action": return "has_action = 1";
            case "schedule": return "has_schedule = 1";
            default: return "";
        }
    }

    private long findIdByFingerprint(String fp) {
        if (fp == null || fp.isEmpty()) return -1;
        try (Cursor c = getReadableDatabase().rawQuery("SELECT id FROM saved_mail WHERE fingerprint=? LIMIT 1", new String[]{fp})) {
            return c.moveToFirst() ? c.getLong(0) : -1;
        }
    }

    public static String fingerprintFor(MailSnapshot m) {
        String basis = norm(m.sender) + "|" + norm(ImportantInfoExtractor.cleanSubject(m.subject)) + "|" +
                norm(m.mailDate) + "|" + norm(m.body);
        try {
            MessageDigest d = MessageDigest.getInstance("SHA-256");
            byte[] bytes = d.digest(basis.getBytes(StandardCharsets.UTF_8));
            StringBuilder b = new StringBuilder();
            for (byte x : bytes) b.append(String.format(Locale.US, "%02x", x & 0xff));
            return b.toString();
        } catch (Exception e) {
            return Integer.toHexString(basis.hashCode());
        }
    }

    private static String norm(String s) {
        return s == null ? "" : s.replace('\u00A0', ' ').replaceAll("\\s+", " ").trim().toLowerCase(Locale.ROOT);
    }

    private String join(List<String> list) {
        StringBuilder b = new StringBuilder();
        for (String s : list) {
            if (b.length() > 0) b.append("\n");
            b.append(s);
        }
        return b.toString();
    }

    private String nz(String s) { return s == null ? "" : s; }
}
