# Secmail Assistant v0.4 Test Guide

## Focus of v0.4
- Local saved-mail deletion: per-message Delete + Delete All with confirmation.
- GPT Review: explicit user-triggered share of one selected saved mail to the ChatGPT Android app.
- Inbox batch automation is intentionally disabled in v0.4 pending a real Inbox UI-tree capture.

## GPT Review behavior
- The app itself still has no INTERNET permission.
- Only when the user taps **GPT 검토** and confirms, an Android ACTION_SEND intent is created.
- Preferred target package: `com.openai.chatgpt`; if not available, Android Sharesheet is shown.
- Shared payload is limited to Subject / Sender / Date / local Action candidates / latest-message segment.
- Older quoted thread is cut at common From/Sent/To/Subject boundaries when possible.
- The prompt asks ChatGPT to summarize the request, mark unknowns as [확인 필요], and draft a reply in the sender's language with a Korean summary.

## Delete test
1. Save 2+ mails locally.
2. Tap **삭제** on one saved-mail card.
3. Confirm deletion and verify count/list refresh.
4. Tap **저장 메일 전체 삭제** and confirm all rows are removed.

## GPT Review test
1. Save a mail locally.
2. Tap **GPT 검토** on that mail card.
3. Confirm the disclosure dialog.
4. Verify ChatGPT opens with a prefilled review prompt / shared text.
5. Confirm the quoted older thread is mostly absent and the latest request is present.

## Deferred item
Full Inbox automatic loading/traversal is deferred. The supplied UI-tree is from the mail detail screen and its `mail_list_view` contains the detail body, so Inbox/detail classification must be verified against a real Inbox tree before automatic clicking is re-enabled.
