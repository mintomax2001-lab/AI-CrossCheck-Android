package com.mintomax.secmailprobe;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private MailDbHelper db;
    private TextView serviceStatus, targetStatus, subjectView, metaView, toView, bodyView;
    private TextView keyView, actionView, scheduleView, savedCountView, debugView;
    private TextView batchStatusView, savedSummaryView;
    private LinearLayout savedListContainer;
    private EditText targetBox;
    private MailSnapshot currentMail;
    private ImportantInfoExtractor.Result currentInfo;
    private boolean bodyExpanded = false;
    private boolean debugExpanded = false;
    private String currentFilter = "all";

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    private TextView text(String s, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(Color.rgb(20, 29, 43));
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setPadding(0, dp(2), 0, dp(5));
        return v;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(13);
        if (primary) {
            b.setBackgroundColor(Color.rgb(37, 99, 235));
            b.setTextColor(Color.WHITE);
        }
        return b;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(14), dp(16), dp(14));
        l.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        l.setLayoutParams(lp);
        return l;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(Color.rgb(229, 234, 242));
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        return v;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(ProbeAccessibilityService.PREFS, Context.MODE_PRIVATE);
        db = new MailDbHelper(this);
        if (prefs.getString(ProbeAccessibilityService.KEY_TARGET, "").trim().isEmpty()) {
            prefs.edit().putString(ProbeAccessibilityService.KEY_TARGET, ProbeAccessibilityService.DEFAULT_TARGET).apply();
        }

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(244, 247, 252));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(16), dp(14), dp(36));
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setPadding(dp(4), dp(4), dp(4), dp(12));
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.mipmap.ic_launcher);
        header.addView(icon, new LinearLayout.LayoutParams(dp(58), dp(58)));
        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.setPadding(dp(12), 0, 0, 0);
        ht.addView(text("Secmail Assistant", 23, true));
        TextView vs = text("v0.3 · Inbox 일괄 확인 + 저장함 필터", 12, false);
        vs.setTextColor(Color.rgb(99, 110, 128));
        ht.addView(vs);
        header.addView(ht, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(header);

        LinearLayout status = card();
        status.addView(text("연결 상태", 16, true));
        serviceStatus = text("", 13, true);
        targetStatus = text("", 12, false);
        status.addView(serviceStatus);
        status.addView(targetStatus);
        LinearLayout statusBtns = new LinearLayout(this);
        Button access = button("접근성 설정", false);
        Button open = button("Secmail 열기", true);
        statusBtns.addView(access, new LinearLayout.LayoutParams(0, dp(50), 1f));
        statusBtns.addView(open, new LinearLayout.LayoutParams(0, dp(50), 1f));
        status.addView(statusBtns);
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        open.setOnClickListener(v -> openSecmail());
        root.addView(status);

        LinearLayout batch = card();
        batch.addView(text("Inbox 일괄 확인 · 실험", 17, true));
        TextView batchNote = text("명시적으로 시작할 때만 Accessibility 클릭/스크롤을 사용합니다. 최대 25개 또는 6개 화면 구간에서 자동 종료합니다.", 11, false);
        batchNote.setTextColor(Color.rgb(99, 110, 128));
        batch.addView(batchNote);
        batchStatusView = text("대기 중", 13, true);
        batch.addView(batchStatusView);
        LinearLayout batchBtns = new LinearLayout(this);
        Button batchStart = button("Inbox 일괄 확인 시작", true);
        Button batchStop = button("중지", false);
        batchBtns.addView(batchStart, new LinearLayout.LayoutParams(0, dp(52), 1.7f));
        batchBtns.addView(batchStop, new LinearLayout.LayoutParams(0, dp(52), 0.7f));
        batch.addView(batchBtns);
        batchStart.setOnClickListener(v -> startBatch());
        batchStop.setOnClickListener(v -> stopBatch("사용자가 중지함"));
        root.addView(batch);

        LinearLayout mail = card();
        mail.addView(text("최근 읽은 메일", 17, true));
        subjectView = text("아직 읽은 메일이 없습니다.", 19, true);
        metaView = text("", 12, false);
        toView = text("", 12, false);
        bodyView = text("", 14, false);
        bodyView.setTextIsSelectable(true);
        mail.addView(subjectView);
        mail.addView(metaView);
        mail.addView(toView);
        mail.addView(divider());
        mail.addView(bodyView);
        LinearLayout mailBtns = new LinearLayout(this);
        Button refresh = button("현재 메일 읽기", true);
        Button save = button("저장", false);
        Button original = button("원문 보기", false);
        mailBtns.addView(refresh, new LinearLayout.LayoutParams(0, dp(50), 1.3f));
        mailBtns.addView(save, new LinearLayout.LayoutParams(0, dp(50), 0.8f));
        mailBtns.addView(original, new LinearLayout.LayoutParams(0, dp(50), 1f));
        mail.addView(mailBtns);
        refresh.setOnClickListener(v -> loadMail());
        save.setOnClickListener(v -> saveCurrentMail());
        original.setOnClickListener(v -> { bodyExpanded = !bodyExpanded; renderMail(); });
        root.addView(mail);

        LinearLayout insights = card();
        insights.addView(text("중요정보 · 로컬 추출", 17, true));
        TextView localNote = text("AI 미사용 · 현재 메일의 요청/행동/일정/업무 키워드를 휴대폰 안에서만 추출", 11, false);
        localNote.setTextColor(Color.rgb(99, 110, 128));
        insights.addView(localNote);
        insights.addView(text("핵심", 13, true));
        keyView = text("—", 13, false);
        insights.addView(keyView);
        insights.addView(text("Action", 13, true));
        actionView = text("—", 13, false);
        insights.addView(actionView);
        insights.addView(text("일정", 13, true));
        scheduleView = text("—", 13, false);
        insights.addView(scheduleView);
        savedCountView = text("로컬 저장 0건", 11, false);
        savedCountView.setTextColor(Color.rgb(99, 110, 128));
        insights.addView(savedCountView);
        root.addView(insights);

        LinearLayout saved = card();
        saved.addView(text("저장함", 18, true));
        savedSummaryView = text("", 11, false);
        savedSummaryView.setTextColor(Color.rgb(99, 110, 128));
        saved.addView(savedSummaryView);
        LinearLayout filters = new LinearLayout(this);
        Button all = button("전체", true);
        Button important = button("중요", false);
        Button action = button("Action", false);
        Button schedule = button("일정", false);
        filters.addView(all, new LinearLayout.LayoutParams(0, dp(46), 1f));
        filters.addView(important, new LinearLayout.LayoutParams(0, dp(46), 1f));
        filters.addView(action, new LinearLayout.LayoutParams(0, dp(46), 1f));
        filters.addView(schedule, new LinearLayout.LayoutParams(0, dp(46), 1f));
        saved.addView(filters);
        savedListContainer = new LinearLayout(this);
        savedListContainer.setOrientation(LinearLayout.VERTICAL);
        savedListContainer.setPadding(0, dp(10), 0, 0);
        saved.addView(savedListContainer);
        all.setOnClickListener(v -> { currentFilter = "all"; renderSavedList(); });
        important.setOnClickListener(v -> { currentFilter = "important"; renderSavedList(); });
        action.setOnClickListener(v -> { currentFilter = "action"; renderSavedList(); });
        schedule.setOnClickListener(v -> { currentFilter = "schedule"; renderSavedList(); });
        root.addView(saved);

        LinearLayout advanced = card();
        advanced.addView(text("고급 / Debug", 15, true));
        Button debug = button("UI-tree Debug 보기/숨기기", false);
        advanced.addView(debug);
        debugView = text("", 10, false);
        debugView.setTypeface(Typeface.MONOSPACE);
        debugView.setTextIsSelectable(true);
        debugView.setVisibility(View.GONE);
        advanced.addView(debugView);
        debug.setOnClickListener(v -> {
            debugExpanded = !debugExpanded;
            debugView.setVisibility(debugExpanded ? View.VISIBLE : View.GONE);
            if (debugExpanded) debugView.setText(prefs.getString(ProbeAccessibilityService.KEY_CAPTURE, "캡처 없음"));
        });
        targetBox = new EditText(this);
        targetBox.setSingleLine(true);
        targetBox.setText(prefs.getString(ProbeAccessibilityService.KEY_TARGET, ProbeAccessibilityService.DEFAULT_TARGET));
        advanced.addView(targetBox);
        Button targetSave = button("Target 저장", false);
        advanced.addView(targetSave);
        targetSave.setOnClickListener(v -> saveTarget());
        TextView scope = text("외부 전송 없음 · OCR 없음 · 메일 서버 직접 접속 없음 · 자동 UI 조작은 Inbox 일괄 확인을 사용자가 명시적으로 시작한 동안만 수행", 11, false);
        scope.setTextColor(Color.rgb(99, 110, 128));
        advanced.addView(scope);
        root.addView(advanced);

        setContentView(scroll);
        refreshStatus();
        loadMail();
        renderSavedList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        loadMail();
        renderSavedList();
    }

    private void refreshStatus() {
        serviceStatus.setText(isAccessibilityEnabled() ? "● Accessibility ON" : "○ Accessibility OFF");
        String target = prefs.getString(ProbeAccessibilityService.KEY_TARGET, ProbeAccessibilityService.DEFAULT_TARGET);
        targetStatus.setText("Target: " + target);
        if (targetBox != null) targetBox.setText(target);
        if (savedCountView != null) savedCountView.setText("로컬 저장 " + db.count() + "건");
        refreshBatchStatus();
    }

    private void refreshBatchStatus() {
        if (batchStatusView == null) return;
        boolean active = prefs.getBoolean(ProbeAccessibilityService.KEY_BATCH_ACTIVE, false);
        int opened = prefs.getInt(ProbeAccessibilityService.KEY_BATCH_OPENED, 0);
        int saved = prefs.getInt(ProbeAccessibilityService.KEY_BATCH_SAVED, 0);
        String status = prefs.getString(ProbeAccessibilityService.KEY_BATCH_STATUS, "대기 중");
        batchStatusView.setText((active ? "● 실행 중 · " : "○ ") + status + "\n열어본 메일 " + opened + " · 새 저장 " + saved);
    }

    private boolean isAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        ComponentName cn = new ComponentName(this, ProbeAccessibilityService.class);
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) {
            String s = splitter.next();
            if (s.equalsIgnoreCase(cn.flattenToString()) || s.equalsIgnoreCase(cn.flattenToShortString())) return true;
        }
        return false;
    }

    private void startBatch() {
        if (!isAccessibilityEnabled()) {
            toast("먼저 Accessibility Service를 ON 해주세요.");
            return;
        }
        prefs.edit()
                .putBoolean(ProbeAccessibilityService.KEY_BATCH_ACTIVE, true)
                .putString(ProbeAccessibilityService.KEY_BATCH_STATUS, "Secmail 실행 중…")
                .putInt(ProbeAccessibilityService.KEY_BATCH_SAVED, 0)
                .putInt(ProbeAccessibilityService.KEY_BATCH_OPENED, 0)
                .putInt(ProbeAccessibilityService.KEY_BATCH_SCROLLS, 0)
                .putInt(ProbeAccessibilityService.KEY_BATCH_DUPES, 0)
                .putString(ProbeAccessibilityService.KEY_BATCH_PROCESSED, "")
                .putString(ProbeAccessibilityService.KEY_BATCH_LAST_FP, "")
                .apply();
        refreshBatchStatus();
        openSecmail();
    }

    private void stopBatch(String reason) {
        prefs.edit()
                .putBoolean(ProbeAccessibilityService.KEY_BATCH_ACTIVE, false)
                .putString(ProbeAccessibilityService.KEY_BATCH_STATUS, reason)
                .apply();
        refreshBatchStatus();
        renderSavedList();
    }

    private void openSecmail() {
        String pkg = prefs.getString(ProbeAccessibilityService.KEY_TARGET, ProbeAccessibilityService.DEFAULT_TARGET).trim();
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) {
            discoverSecmail();
            pkg = prefs.getString(ProbeAccessibilityService.KEY_TARGET, ProbeAccessibilityService.DEFAULT_TARGET).trim();
            launch = getPackageManager().getLaunchIntentForPackage(pkg);
        }
        if (launch == null) { toast("Secmail 실행 Activity를 찾지 못했습니다."); return; }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(launch);
    }

    private void discoverSecmail() {
        PackageManager pm = getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
        for (ResolveInfo ri : list) {
            String pkg = ri.activityInfo.packageName;
            if (getPackageName().equals(pkg)) continue;
            CharSequence label = ri.loadLabel(pm);
            String l = label == null ? "" : label.toString().toLowerCase(Locale.ROOT);
            if (pkg.equals(ProbeAccessibilityService.DEFAULT_TARGET) || l.contains("secmail")) {
                prefs.edit().putString(ProbeAccessibilityService.KEY_TARGET, pkg).apply();
                return;
            }
        }
    }

    private void saveTarget() {
        String pkg = targetBox.getText().toString().trim();
        if (pkg.isEmpty()) { toast("Package name을 입력하세요."); return; }
        if (pkg.equals(getPackageName())) { toast("Reader 자체 package는 Target으로 사용할 수 없습니다."); return; }
        prefs.edit().putString(ProbeAccessibilityService.KEY_TARGET, pkg).apply();
        refreshStatus();
        toast("Target 저장 완료");
    }

    private void loadMail() {
        MailSnapshot m = new MailSnapshot();
        m.subject = prefs.getString(ProbeAccessibilityService.KEY_SUBJECT, "");
        m.sender = prefs.getString(ProbeAccessibilityService.KEY_SENDER, "");
        m.recipients = prefs.getString(ProbeAccessibilityService.KEY_RECIPIENTS, "");
        m.mailDate = prefs.getString(ProbeAccessibilityService.KEY_MAIL_DATE, "");
        m.body = prefs.getString(ProbeAccessibilityService.KEY_BODY, "");
        m.capturedAt = prefs.getString(ProbeAccessibilityService.KEY_CAPTURE_TIME, "");
        m.packageName = prefs.getString(ProbeAccessibilityService.KEY_CAPTURE_PKG, "");
        currentMail = m;
        currentInfo = ImportantInfoExtractor.extract(m.subject, m.body);
        renderMail();
        if (debugExpanded) debugView.setText(prefs.getString(ProbeAccessibilityService.KEY_CAPTURE, "캡처 없음"));
    }

    private void renderMail() {
        if (currentMail == null || !currentMail.hasMailContent()) {
            subjectView.setText("아직 읽은 메일이 없습니다.");
            metaView.setText("Secmail에서 메일을 열거나 Inbox 일괄 확인을 시작하세요.");
            toView.setText("");
            bodyView.setText("");
            keyView.setText("—"); actionView.setText("—"); scheduleView.setText("—");
            return;
        }
        String cleanSubject = ImportantInfoExtractor.cleanSubject(currentMail.subject);
        subjectView.setText(empty(cleanSubject, "(제목 없음)"));
        String priority = currentInfo == null ? "" : " · " + currentInfo.importanceLabel + " " + currentInfo.importanceScore;
        metaView.setText("From: " + empty(currentMail.sender, "—") + "   ·   " + empty(currentMail.mailDate, "시간 미확인") + priority);
        toView.setText("To: " + empty(currentMail.recipients, "—"));
        String body = currentMail.body == null ? "" : currentMail.body;
        if (!bodyExpanded && body.length() > 420) body = body.substring(0, 420) + "…";
        bodyView.setText(body);
        keyView.setText(bullets(currentInfo.keyPoints));
        actionView.setText(bullets(currentInfo.actions));
        scheduleView.setText(bullets(currentInfo.schedules));
    }

    private void saveCurrentMail() {
        if (currentMail == null || !currentMail.hasMailContent()) { toast("먼저 메일을 읽어오세요."); return; }
        MailDbHelper.SaveResult sr = db.saveIfNew(currentMail, currentInfo);
        if (sr.inserted) toast("로컬 저장 완료");
        else if (sr.duplicate) toast("이미 저장된 메일입니다.");
        else toast("저장 실패");
        refreshStatus();
        renderSavedList();
    }

    private void renderSavedList() {
        if (savedListContainer == null) return;
        savedListContainer.removeAllViews();
        int all = db.countFilter("all");
        int important = db.countFilter("important");
        int action = db.countFilter("action");
        int schedule = db.countFilter("schedule");
        savedSummaryView.setText("전체 " + all + " · 중요 " + important + " · Action " + action + " · 일정 " + schedule);
        List<SavedMailRecord> records = db.list(currentFilter, 50);
        if (records.isEmpty()) {
            savedListContainer.addView(text("해당 조건의 저장 메일이 없습니다.", 12, false));
            return;
        }
        for (SavedMailRecord r : records) addSavedRow(r);
    }

    private void addSavedRow(SavedMailRecord r) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(dp(2), dp(10), dp(2), dp(10));
        String badge = r.importance >= 3 ? "[중요] " : (r.importance >= 1 ? "[확인] " : "");
        TextView title = text(badge + empty(ImportantInfoExtractor.cleanSubject(r.subject), "(제목 없음)"), 14, true);
        item.addView(title);
        TextView meta = text(empty(r.sender, "발신자 미확인") + " · " + empty(r.mailDate, formatSavedAt(r.savedAt)), 11, false);
        meta.setTextColor(Color.rgb(99, 110, 128));
        item.addView(meta);
        String preview = firstNonEmptyLine(r.keyPoints);
        if (!preview.isEmpty()) item.addView(text("핵심 · " + trim(preview, 150), 12, false));
        if (!r.actions.trim().isEmpty()) item.addView(text("Action · " + trim(firstNonEmptyLine(r.actions), 150), 12, false));
        if (!r.schedules.trim().isEmpty()) item.addView(text("일정 · " + trim(firstNonEmptyLine(r.schedules), 150), 12, false));
        Button view = button("이 메일 보기", false);
        item.addView(view, new LinearLayout.LayoutParams(-1, dp(44)));
        view.setOnClickListener(v -> showSavedRecord(r));
        savedListContainer.addView(item);
        savedListContainer.addView(divider());
    }

    private void showSavedRecord(SavedMailRecord r) {
        currentMail = r.toSnapshot();
        currentInfo = ImportantInfoExtractor.extract(currentMail.subject, currentMail.body);
        bodyExpanded = true;
        renderMail();
        toast("상단 '최근 읽은 메일'에 저장 메일을 불러왔습니다.");
    }

    private String bullets(List<String> list) {
        if (list == null || list.isEmpty()) return "—";
        StringBuilder b = new StringBuilder();
        for (String s : list) {
            if (b.length() > 0) b.append('\n');
            b.append("• ").append(s);
        }
        return b.toString();
    }

    private String firstNonEmptyLine(String s) {
        if (s == null) return "";
        for (String line : s.split("\\n")) if (!line.trim().isEmpty()) return line.trim();
        return "";
    }

    private String formatSavedAt(long ms) {
        if (ms <= 0) return "";
        return new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(new Date(ms));
    }

    private String trim(String s, int max) {
        if (s == null) return "";
        String x = s.replaceAll("\\s+", " ").trim();
        return x.length() <= max ? x : x.substring(0, max - 1) + "…";
    }

    private String empty(String s, String fallback) { return s == null || s.trim().isEmpty() ? fallback : s.trim(); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
