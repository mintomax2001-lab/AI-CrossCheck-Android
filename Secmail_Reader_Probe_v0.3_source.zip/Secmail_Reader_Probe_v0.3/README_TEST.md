# Secmail Assistant v0.3 — Test Guide

## Goal
v0.3 moves from single-mail PoC to a usable local inbox workflow:
1. Browse saved mail locally with filters.
2. Explicitly start an experimental Inbox batch pass.
3. Use only Accessibility nodes exposed by Secmail; no OCR, no mail-server access, no external transmission.

## Confirmed from v0.2
- Target package: `com.uusafe.secmail`
- Subject / Sender / To / Date / Body are readable from Accessibility UI tree.
- WebView body text is available without OCR.
- SQLite local save works.

## New in v0.3
- Saved Mail views: All / Important / Action / Schedule.
- Duplicate prevention using a local SHA-256 fingerprint.
- Existing v0.2 DB migration/backfill.
- Improved local extraction to reduce quoted-thread/header noise.
- Explicit `Inbox 일괄 확인 시작` experiment.
- Batch automation safety limits: max 25 opened messages, max 6 scroll segments, stop after 3 consecutive duplicates.
- Auto actions only while the user explicitly enables the batch session.

## Batch behavior
The Accessibility service tries to:
`Secmail/Inbox → identify a visible mail list → click a row → wait for body → parse/save → Back → next row → scroll → stop`

Because the exact Inbox row hierarchy has not yet been captured, this is deliberately an experimental implementation. If the list is not recognized, the app displays that it is waiting for the Inbox and does not bypass Android/MDM restrictions.

## Test sequence
1. Install v0.3 and verify Accessibility remains ON; if Android requires re-approval after reinstall, enable it again.
2. Open Secmail Assistant and check existing saved mails under `저장함`.
3. Test filters: 전체 / 중요 / Action / 일정.
4. Tap `Inbox 일괄 확인 시작`.
5. If Secmail does not land in Inbox, manually open Inbox once.
6. Observe whether rows open automatically, are saved, then return to the list.
7. Return to Secmail Assistant and inspect counts/cards.
8. If batch recognition fails, copy only the Inbox UI-tree Debug output with confidential text redacted; do not share raw corporate mail body unnecessarily.

## Known limitations
- Automatic Inbox traversal is heuristic until the actual Inbox Accessibility tree is captured.
- v0.3 does not guarantee Android silent/background mail sync.
- No fixed release signing key yet; sideload update compatibility is not guaranteed across GitHub Actions debug builds.
- No external AI analysis in this version.
