# Secmail Assistant v0.5 Test Guide

## v0.5 concept
Secmail Assistant is not a replacement email client. It is a local Tech Marketing Action Inbox layered on top of Secmail.

Collection rule: **processed vs. unprocessed**, not read vs. unread.
- A mail is collected if Secmail Assistant has not processed that Inbox row before.
- Read/unread state is not used as a gate.
- Deleted saved mail keeps a collection-index tombstone so it is not immediately re-imported.
- Use `수집 이력 초기화` only when you intentionally want old mail to be collectible again.

## Main additions
1. Explicit `미수집 메일 확인` batch collector.
2. Detail-screen guard: WebView/body/reply UI is not treated as Inbox list.
3. Persistent collection index independent from saved-mail rows.
4. Initial safe backfill ceiling: max 50 opened mails / 10 list scrolls.
5. Latest-message extraction stored separately from full thread.
6. Action Inbox status candidates: 회신 필요 / Action / 일정 / FYI.
7. Manual status override: 대기 중 / 완료 included for follow-up workflow.
8. Search across subject, sender, recipient, latest message, key points, actions, tags.
9. Local topic tags: PDK, NTO/MPW, Process/Tool, Customer/VOC, Pricing/CoM, Capacity, Quality/Yield, Meeting/Visit, Roadmap/Proposal.
10. GPT Review privacy choice: local summary only OR latest message included.

## Test sequence
### A. Upgrade and DB migration
- Install stable-signed v0.5 over stable v0.4.
- Confirm old locally saved mail remains visible.
- Confirm no crash when opening Action Inbox.

### B. Action Inbox
- Verify counts for 전체 / 회신·Action / 대기 / 일정 / FYI.
- Search a known sender/subject keyword.
- Change one mail to 대기 중 and another to 완료; verify filters.
- Verify individual delete still works.

### C. GPT Review
- Tap GPT 검토 → 로컬 요약만 전달: confirm no full Latest Message is included in the shared prompt.
- Tap GPT 검토 → 최신 본문 포함: confirm latest-message segment is included after confirmation.

### D. Unprocessed collector
1. Open Secmail Inbox before or after pressing `미수집 메일 확인`.
2. Start batch collection.
3. Observe whether it opens actual Inbox rows, captures one detail mail, returns, and continues.
4. It must ignore read/unread state.
5. Stop immediately if it clicks a navigation item or anything other than a mail row.
6. After completion, run it again: already processed rows should be skipped.

## Important validation gate
The exact Secmail Inbox Accessibility tree has not yet been captured. v0.5 adds stronger screen classification and conservative row scoring, but Inbox automation remains a device-validation feature. If it cannot find rows or clicks the wrong item, capture the Inbox UI-tree with Debug while the Inbox list itself is visible and refine selectors before increasing automation scope.

## Security boundary
- No INTERNET permission in Secmail Assistant.
- No OCR.
- No mail-server credential/API access.
- No security-control bypass.
- UI automation only while explicitly started by the user.
- GPT content transfer only after explicit per-mail user action and scope selection.
