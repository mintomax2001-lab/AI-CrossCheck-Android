package com.mintomax.secmailprobe;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private MailDbHelper db;
    private TextView serviceStatus, targetStatus, subjectView, metaView, toView, bodyView;
    private TextView keyView, actionView, scheduleView, savedCountView, debugView;
    private TextView batchStatusView, savedSummaryView;
    private LinearLayout savedListContainer;
    private EditText targetBox, searchBox;
    private MailSnapshot currentMail;
    private ImportantInfoExtractor.Result currentInfo;
    private boolean bodyExpanded = false;
    private boolean debugExpanded = false;
    private String currentFilter = "all";
    private String currentQuery = "";

    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }

    private TextView text(String s, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(Color.rgb(20, 29, 43));
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setPadding(0, dp(2), 0, dp(5));
        return v;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(13);
        if (primary) {
            b.setBackgroundColor(Color.rgb(37, 99, 235));
            b.setTextColor(Color.WHITE);
        }
        return b;
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(14), dp(16), dp(14));
        l.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(10));
        l.setLayoutParams(lp);
        return l;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(Color.rgb(229, 234, 242));
        v.setLayoutParams(new LinearLayout.LayoutParams(-1, dp(1)));
        return v;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(ProbeAccessibilityService.PREFS, Context.MODE_PRIVATE);
        db = new MailDbHelper(this);
        if (prefs.getString(ProbeAccessibilityService.KEY_TARGET, "").trim().isEmpty()) {
            prefs.edit().putString(ProbeAccessibilityService.KEY_TARGET, ProbeAccessibilityService.DEFAULT_TARGET).apply();
        }

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(244, 247, 252));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(16), dp(14), dp(36));
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setPadding(dp(4), dp(4), dp(4), dp(12));
        ImageView icon = new ImageView(this);
        icon.setImageResource(R.mipmap.ic_launcher);
        header.addView(icon, new LinearLayout.LayoutParams(dp(58), dp(58)));
        LinearLayout ht = new LinearLayout(this);
        ht.setOrientation(LinearLayout.VERTICAL);
        ht.setPadding(dp(12), 0, 0, 0);
        ht.addView(text("Secmail Assistant", 23, true));
        TextView vs = text("v0.5 · Unprocessed Collector + Action Inbox", 12, false);
        vs.setTextColor(Color.rgb(99, 110, 128));
        ht.addView(vs);
        header.addView(ht, new LinearLayout.LayoutParams(0, -2, 1f));
        root.addView(header);

        LinearLayout status = card();
        status.addView(text("연결 상태", 16, true));
        serviceStatus = text("", 13, true);
        targetStatus = text("", 12, false);
        status.addView(serviceStatus);
        status.addView(targetStatus);
        LinearLayout statusBtns = new LinearLayout(this);
        Button access = button("접근성 설정", false);
        Button open = button("Secmail 열기", true);
        statusBtns.addView(access, new LinearLayout.LayoutParams(0, dp(50), 1f));
        statusBtns.addView(open, new LinearLayout.LayoutParams(0, dp(50), 1f));
        status.addView(statusBtns);
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        open.setOnClickListener(v -> openSecmail());
        root.addView(status);

        LinearLayout batch = card();
        batch.addView(text("미수집 메일 일괄 수집", 17, true));
        TextView batchNote = text("읽음/안읽음 상태는 수집 기준으로 사용하지 않습니다. Assistant가 아직 처리하지 않은 Inbox 메일만 열어 로컬 저장하며, 사용자가 버튼을 누른 동안에만 동작합니다.", 11, false);
        batchNote.setTextColor(Color.rgb(99, 110, 128));
        batch.addView(batchNote);
        batchStatusView = text("대기 중", 13, true);
        batch.addView(batchStatusView);
        LinearLayout batchBtns = new LinearLayout(this);
        Button batchStart = button("미수집 메일 확인", true);
        Button batchStop = button("중지", false);
        batchBtns.addView(batchStart, new LinearLayout.LayoutParams(0, dp(52), 1.7f));
        batchBtns.addView(batchStop, new LinearLayout.LayoutParams(0, dp(52), 0.7f));
        batch.addView(batchBtns);
        batchStart.setOnClickListener(v -> confirmStartBatch());
        batchStop.setOnClickListener(v -> stopBatch("사용자 중지"));
        root.addView(batch);

        LinearLayout mail = card();
        mail.addView(text("최근 읽은 메일", 17, true));
        subjectView = text("아직 읽은 메일이 없습니다.", 19, true);
        metaView = text("", 12, false);
        toView = text("", 12, false);
        bodyView = text("", 14, false);
        bodyView.setTextIsSelectable(true);
        mail.addView(subjectView);
        mail.addView(metaView);
        mail.addView(toView);
        mail.addView(divider());
        mail.addView(bodyView);
        LinearLayout mailBtns = new LinearLayout(this);
        Button refresh = button("현재 메일 읽기", true);
        Button save = button("저장", false);
        Button original = button("원문 보기", false);
        mailBtns.addView(refresh, new LinearLayout.LayoutParams(0, dp(50), 1.3f));
        mailBtns.addView(save, new LinearLayout.LayoutParams(0, dp(50), 0.8f));
        mailBtns.addView(original, new LinearLayout.LayoutParams(0, dp(50), 1f));
        mail.addView(mailBtns);
        refresh.setOnClickListener(v -> loadMail());
        save.setOnClickListener(v -> saveCurrentMail());
        original.setOnClickListener(v -> { bodyExpanded = !bodyExpanded; renderMail(); });
        root.addView(mail);

        LinearLayout insights = card();
        insights.addView(text("중요정보 · 로컬 추출", 17, true));
        TextView localNote = text("AI 미사용 · 현재 메일의 요청/행동/일정/업무 키워드를 휴대폰 안에서만 추출", 11, false);
        localNote.setTextColor(Color.rgb(99, 110, 128));
        insights.addView(localNote);
        insights.addView(text("핵심", 13, true));
        keyView = text("—", 13, false);
        insights.addView(keyView);
        insights.addView(text("Action", 13, true));
        actionView = text("—", 13, false);
        insights.addView(actionView);
        insights.addView(text("일정", 13, true));
        scheduleView = text("—", 13, false);
        insights.addView(scheduleView);
        savedCountView = text("로컬 저장 0건", 11, false);
        savedCountView.setTextColor(Color.rgb(99, 110, 128));
        insights.addView(savedCountView);
        root.addView(insights);

        LinearLayout saved = card();
        saved.addView(text("Action Inbox", 18, true));
        TextView savedNote = text("메일 원문보다 '내가 무엇을 해야 하는지'를 먼저 봅니다. 자동 분류는 후보이며 상태는 직접 바꿀 수 있습니다.", 11, false);
        savedNote.setTextColor(Color.rgb(99, 110, 128));
        saved.addView(savedNote);
        savedSummaryView = text("", 11, false);
        savedSummaryView.setTextColor(Color.rgb(99, 110, 128));
        saved.addView(savedSummaryView);

        LinearLayout searchRow = new LinearLayout(this);
        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setHint("고객 / 제목 / 키워드 검색");
        Button searchBtn = button("검색", true);
        Button clearSearch = button("초기화", false);
        searchRow.addView(searchBox, new LinearLayout.LayoutParams(0, dp(50), 1.8f));
        searchRow.addView(searchBtn, new LinearLayout.LayoutParams(0, dp(50), 0.8f));
        searchRow.addView(clearSearch, new LinearLayout.LayoutParams(0, dp(50), 0.8f));
        saved.addView(searchRow);
        searchBtn.setOnClickListener(v -> { currentQuery = searchBox.getText().toString().trim(); renderSavedList(); });
        clearSearch.setOnClickListener(v -> { currentQuery = ""; searchBox.setText(""); renderSavedList(); });

        LinearLayout filters1 = new LinearLayout(this);
        Button all = button("전체", true);
        Button attention = button("회신/Action", false);
        Button waiting = button("대기", false);
        filters1.addView(all, new LinearLayout.LayoutParams(0, dp(46), 1f));
        filters1.addView(attention, new LinearLayout.LayoutParams(0, dp(46), 1.2f));
        filters1.addView(waiting, new LinearLayout.LayoutParams(0, dp(46), 1f));
        saved.addView(filters1);
        LinearLayout filters2 = new LinearLayout(this);
        Button schedule = button("일정", false);
        Button fyi = button("FYI", false);
        Button done = button("완료", false);
        filters2.addView(schedule, new LinearLayout.LayoutParams(0, dp(46), 1f));
        filters2.addView(fyi, new LinearLayout.LayoutParams(0, dp(46), 1f));
        filters2.addView(done, new LinearLayout.LayoutParams(0, dp(46), 1f));
        saved.addView(filters2);
        all.setOnClickListener(v -> { currentFilter = "all"; renderSavedList(); });
        attention.setOnClickListener(v -> { currentFilter = "attention"; renderSavedList(); });
        waiting.setOnClickListener(v -> { currentFilter = "waiting"; renderSavedList(); });
        schedule.setOnClickListener(v -> { currentFilter = "schedule"; renderSavedList(); });
        fyi.setOnClickListener(v -> { currentFilter = "fyi"; renderSavedList(); });
        done.setOnClickListener(v -> { currentFilter = "done"; renderSavedList(); });

        Button deleteAll = button("저장 메일 전체 삭제", false);
        saved.addView(deleteAll, new LinearLayout.LayoutParams(-1, dp(44)));
        deleteAll.setOnClickListener(v -> confirmDeleteAll());
        savedListContainer = new LinearLayout(this);
        savedListContainer.setOrientation(LinearLayout.VERTICAL);
        savedListContainer.setPadding(0, dp(10), 0, 0);
        saved.addView(savedListContainer);
        root.addView(saved);

        LinearLayout advanced = card();
        advanced.addView(text("고급 / Debug", 15, true));
        Button debug = button("UI-tree Debug 보기/숨기기", false);
        advanced.addView(debug);
        debugView = text("", 10, false);
        debugView.setTypeface(Typeface.MONOSPACE);
        debugView.setTextIsSelectable(true);
        debugView.setVisibility(View.GONE);
        advanced.addView(debugView);
        debug.setOnClickListener(v -> {
            debugExpanded = !debugExpanded;
            debugView.setVisibility(debugExpanded ? View.VISIBLE : View.GONE);
            if (debugExpanded) debugView.setText(prefs.getString(ProbeAccessibilityService.KEY_CAPTURE, "캡처 없음"));
        });
        targetBox = new EditText(this);
        targetBox.setSingleLine(true);
        targetBox.setText(prefs.getString(ProbeAccessibilityService.KEY_TARGET, ProbeAccessibilityService.DEFAULT_TARGET));
        advanced.addView(targetBox);
        Button targetSave = button("Target 저장", false);
        advanced.addView(targetSave);
        targetSave.setOnClickListener(v -> saveTarget());
        Button resetIndex = button("수집 이력 초기화", false);
        advanced.addView(resetIndex);
        resetIndex.setOnClickListener(v -> confirmResetCollectionIndex());
        TextView scope = text("기본 로컬 처리 · OCR 없음 · 메일 서버 직접 접속 없음 · GPT 검토는 사용자가 선택한 메일만 확인 후 공유 · 자동 UI 조작은 사용자가 명시적으로 시작한 동안만 수행 · 읽음/안읽음은 수집 기준이 아님", 11, false);
        scope.setTextColor(Color.rgb(99, 110, 128));
        advanced.addView(scope);
        root.addView(advanced);

        setContentView(scroll);
        refreshStatus();
        loadMail();
        renderSavedList();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
        loadMail();
        renderSavedList();
    }

    private void refreshStatus() {
        serviceStatus.setText(isAccessibilityEnabled() ? "● Accessibility ON" : "○ Accessibility OFF");
        String target = prefs.getString(ProbeAccessibilityService.KEY_TARGET, ProbeAccessibilityService.DEFAULT_TARGET);
        targetStatus.setText("Target: " + target);
        if (targetBox != null) targetBox.setText(target);
        if (savedCountView != null) savedCountView.setText("로컬 저장 " + db.count() + "건");
        refreshBatchStatus();
    }

    private void refreshBatchStatus() {
        if (batchStatusView == null) return;
        boolean active = prefs.getBoolean(ProbeAccessibilityService.KEY_BATCH_ACTIVE, false);
        int opened = prefs.getInt(ProbeAccessibilityService.KEY_BATCH_OPENED, 0);
        int saved = prefs.getInt(ProbeAccessibilityService.KEY_BATCH_SAVED, 0);
        int known = prefs.getInt(ProbeAccessibilityService.KEY_BATCH_KNOWN, 0);
        String status = prefs.getString(ProbeAccessibilityService.KEY_BATCH_STATUS, "대기 중");
        batchStatusView.setText((active ? "● 실행 중 · " : "○ ") + status + "\n열어본 메일 " + opened + " · 새 저장 " + saved + " · 기존 처리 " + known);
    }

    private boolean isAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        ComponentName cn = new ComponentName(this, ProbeAccessibilityService.class);
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) {
            String s = splitter.next();
            if (s.equalsIgnoreCase(cn.flattenToString()) || s.equalsIgnoreCase(cn.flattenToShortString())) return true;
        }
        return false;
    }

    private void confirmStartBatch() {
        new AlertDialog.Builder(this)
                .setTitle("미수집 메일 일괄 확인")
                .setMessage("읽음/안읽음과 관계없이 Secmail Assistant가 아직 처리하지 않은 Inbox 메일을 확인합니다.\n\n최대 50개 메일 / 10개 목록 구간까지만 자동으로 열며, 이미 처리한 메일은 건너뜁니다. 진행할까요?")
                .setNegativeButton("취소", null)
                .setPositiveButton("시작", (d, w) -> startBatch())
                .show();
    }

    private void startBatch() {
        if (!isAccessibilityEnabled()) {
            toast("먼저 Accessibility Service를 ON 해주세요.");
            return;
        }
        prefs.edit()
                .putBoolean(ProbeAccessibilityService.KEY_BATCH_ACTIVE, true)
                .putString(ProbeAccessibilityService.KEY_BATCH_STATUS, "Secmail 실행 중…")
                .putInt(ProbeAccessibilityService.KEY_BATCH_SAVED, 0)
                .putInt(ProbeAccessibilityService.KEY_BATCH_OPENED, 0)
                .putInt(ProbeAccessibilityService.KEY_BATCH_SCROLLS, 0)
                .putInt(ProbeAccessibilityService.KEY_BATCH_DUPES, 0)
                .putInt(ProbeAccessibilityService.KEY_BATCH_KNOWN, 0)
                .putString(ProbeAccessibilityService.KEY_BATCH_PROCESSED, "")
                .putString(ProbeAccessibilityService.KEY_BATCH_LAST_FP, "")
                .putString(ProbeAccessibilityService.KEY_BATCH_PENDING_LIST_SIG, "")
                .putString(ProbeAccessibilityService.KEY_BATCH_PENDING_PREVIEW, "")
                .apply();
        refreshBatchStatus();
        openSecmail();
    }

    private void stopBatch(String reason) {
        prefs.edit()
                .putBoolean(ProbeAccessibilityService.KEY_BATCH_ACTIVE, false)
                .putString(ProbeAccessibilityService.KEY_BATCH_STATUS, reason)
                .apply();
        refreshBatchStatus();
        renderSavedList();
    }

    private void openSecmail() {
        String pkg = prefs.getString(ProbeAccessibilityService.KEY_TARGET, ProbeAccessibilityService.DEFAULT_TARGET).trim();
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) {
            discoverSecmail();
            pkg = prefs.getString(ProbeAccessibilityService.KEY_TARGET, ProbeAccessibilityService.DEFAULT_TARGET).trim();
            launch = getPackageManager().getLaunchIntentForPackage(pkg);
        }
        if (launch == null) { toast("Secmail 실행 Activity를 찾지 못했습니다."); return; }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(launch);
    }

    private void discoverSecmail() {
        PackageManager pm = getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
        for (ResolveInfo ri : list) {
            String pkg = ri.activityInfo.packageName;
            if (getPackageName().equals(pkg)) continue;
            CharSequence label = ri.loadLabel(pm);
            String l = label == null ? "" : label.toString().toLowerCase(Locale.ROOT);
            if (pkg.equals(ProbeAccessibilityService.DEFAULT_TARGET) || l.contains("secmail")) {
                prefs.edit().putString(ProbeAccessibilityService.KEY_TARGET, pkg).apply();
                return;
            }
        }
    }

    private void saveTarget() {
        String pkg = targetBox.getText().toString().trim();
        if (pkg.isEmpty()) { toast("Package name을 입력하세요."); return; }
        if (pkg.equals(getPackageName())) { toast("Reader 자체 package는 Target으로 사용할 수 없습니다."); return; }
        prefs.edit().putString(ProbeAccessibilityService.KEY_TARGET, pkg).apply();
        refreshStatus();
        toast("Target 저장 완료");
    }

    private void loadMail() {
        MailSnapshot m = new MailSnapshot();
        m.subject = prefs.getString(ProbeAccessibilityService.KEY_SUBJECT, "");
        m.sender = prefs.getString(ProbeAccessibilityService.KEY_SENDER, "");
        m.recipients = prefs.getString(ProbeAccessibilityService.KEY_RECIPIENTS, "");
        m.mailDate = prefs.getString(ProbeAccessibilityService.KEY_MAIL_DATE, "");
        m.body = prefs.getString(ProbeAccessibilityService.KEY_BODY, "");
        m.capturedAt = prefs.getString(ProbeAccessibilityService.KEY_CAPTURE_TIME, "");
        m.packageName = prefs.getString(ProbeAccessibilityService.KEY_CAPTURE_PKG, "");
        currentMail = m;
        currentInfo = ImportantInfoExtractor.extract(m.subject, m.body);
        renderMail();
        if (debugExpanded) debugView.setText(prefs.getString(ProbeAccessibilityService.KEY_CAPTURE, "캡처 없음"));
    }

    private void renderMail() {
        if (currentMail == null || !currentMail.hasMailContent()) {
            subjectView.setText("아직 읽은 메일이 없습니다.");
            metaView.setText("Secmail에서 메일을 열거나 Inbox 일괄 확인을 시작하세요.");
            toView.setText("");
            bodyView.setText("");
            keyView.setText("—"); actionView.setText("—"); scheduleView.setText("—");
            return;
        }
        String cleanSubject = ImportantInfoExtractor.cleanSubject(currentMail.subject);
        subjectView.setText(empty(cleanSubject, "(제목 없음)"));
        String priority = currentInfo == null ? "" : " · " + currentInfo.importanceLabel + " " + currentInfo.importanceScore;
        metaView.setText("From: " + empty(currentMail.sender, "—") + "   ·   " + empty(currentMail.mailDate, "시간 미확인") + priority);
        toView.setText("To: " + empty(currentMail.recipients, "—"));
        String body = currentMail.body == null ? "" : currentMail.body;
        if (!bodyExpanded && body.length() > 420) body = body.substring(0, 420) + "…";
        bodyView.setText(body);
        keyView.setText(bullets(currentInfo.keyPoints));
        actionView.setText(bullets(currentInfo.actions));
        scheduleView.setText(bullets(currentInfo.schedules));
    }

    private void saveCurrentMail() {
        if (currentMail == null || !currentMail.hasMailContent()) { toast("먼저 메일을 읽어오세요."); return; }
        MailDbHelper.SaveResult sr = db.saveIfNew(currentMail, currentInfo);
        if (sr.inserted) toast("로컬 저장 완료");
        else if (sr.duplicate) toast("이미 저장된 메일입니다.");
        else toast("저장 실패");
        refreshStatus();
        renderSavedList();
    }

    private void renderSavedList() {
        if (savedListContainer == null) return;
        savedListContainer.removeAllViews();
        int all = db.countFilter("all");
        int attention = db.countFilter("attention");
        int waiting = db.countFilter("waiting");
        int schedule = db.countFilter("schedule");
        int fyi = db.countFilter("fyi");
        savedSummaryView.setText("전체 " + all + " · 회신/Action " + attention + " · 대기 " + waiting + " · 일정 " + schedule + " · FYI " + fyi);
        List<SavedMailRecord> records = db.list(currentFilter, currentQuery, 100);
        if (records.isEmpty()) {
            savedListContainer.addView(text(currentQuery.isEmpty() ? "해당 조건의 저장 메일이 없습니다." : "검색 결과가 없습니다.", 12, false));
            return;
        }
        for (SavedMailRecord r : records) addSavedRow(r);
    }

    private void addSavedRow(SavedMailRecord r) {
        LinearLayout item = new LinearLayout(this);
        item.setOrientation(LinearLayout.VERTICAL);
        item.setPadding(dp(2), dp(10), dp(2), dp(10));
        String badge = "[" + workflowLabel(r.workflowStatus) + "] ";
        if (r.importance >= 3) badge = "[중요] " + badge;
        TextView title = text(badge + empty(ImportantInfoExtractor.cleanSubject(r.subject), "(제목 없음)"), 14, true);
        item.addView(title);
        TextView meta = text(empty(r.sender, "발신자 미확인") + " · " + empty(r.mailDate, formatSavedAt(r.savedAt)), 11, false);
        meta.setTextColor(Color.rgb(99, 110, 128));
        item.addView(meta);
        if (!r.topicTags.trim().isEmpty()) {
            TextView tags = text("Tags · " + r.topicTags.replace("\n", " · "), 11, false);
            tags.setTextColor(Color.rgb(61, 91, 145));
            item.addView(tags);
        }
        String preview = firstNonEmptyLine(r.keyPoints);
        if (!preview.isEmpty()) item.addView(text("핵심 · " + trim(preview, 160), 12, false));
        if (!r.actions.trim().isEmpty()) item.addView(text("Action · " + trim(firstNonEmptyLine(r.actions), 160), 12, false));
        if (!r.schedules.trim().isEmpty()) item.addView(text("일정 · " + trim(firstNonEmptyLine(r.schedules), 160), 12, false));

        LinearLayout rowBtns = new LinearLayout(this);
        Button view = button("보기", false);
        Button gpt = button("GPT 검토", true);
        Button status = button("상태", false);
        Button delete = button("삭제", false);
        rowBtns.addView(view, new LinearLayout.LayoutParams(0, dp(44), 0.8f));
        rowBtns.addView(gpt, new LinearLayout.LayoutParams(0, dp(44), 1.1f));
        rowBtns.addView(status, new LinearLayout.LayoutParams(0, dp(44), 0.8f));
        rowBtns.addView(delete, new LinearLayout.LayoutParams(0, dp(44), 0.7f));
        item.addView(rowBtns);
        view.setOnClickListener(v -> showSavedRecord(r));
        gpt.setOnClickListener(v -> confirmGptReview(r));
        status.setOnClickListener(v -> chooseWorkflowStatus(r));
        delete.setOnClickListener(v -> confirmDelete(r));
        savedListContainer.addView(item);
        savedListContainer.addView(divider());
    }

    private String workflowLabel(String status) {
        if ("reply".equals(status)) return "회신 필요";
        if ("action".equals(status)) return "Action";
        if ("waiting".equals(status)) return "대기 중";
        if ("schedule".equals(status)) return "일정";
        if ("done".equals(status)) return "완료";
        return "FYI";
    }

    private void chooseWorkflowStatus(SavedMailRecord r) {
        String[] labels = new String[]{"회신 필요", "내부 Action", "대기 중", "일정", "FYI", "완료"};
        String[] values = new String[]{"reply", "action", "waiting", "schedule", "fyi", "done"};
        new AlertDialog.Builder(this)
                .setTitle("업무 상태 변경")
                .setItems(labels, (d, which) -> {
                    int n = db.updateWorkflowStatus(r.id, values[which]);
                    if (n > 0) toast("상태 변경: " + labels[which]);
                    renderSavedList();
                })
                .setNegativeButton("취소", null)
                .show();
    }

    private void confirmDelete(SavedMailRecord r) {
        new AlertDialog.Builder(this)
                .setTitle("저장 메일 삭제")
                .setMessage("이 메일을 로컬 저장함에서 삭제할까요?\n\n" + trim(ImportantInfoExtractor.cleanSubject(r.subject), 100) + "\n\n※ 수집 이력은 남겨 다음 자동 수집 때 같은 메일을 다시 가져오지 않습니다.")
                .setNegativeButton("취소", null)
                .setPositiveButton("삭제", (d, w) -> {
                    int n = db.deleteById(r.id);
                    if (n > 0) toast("삭제 완료"); else toast("삭제할 메일을 찾지 못했습니다.");
                    refreshStatus();
                    renderSavedList();
                })
                .show();
    }

    private void confirmDeleteAll() {
        int count = db.count();
        if (count <= 0) { toast("삭제할 저장 메일이 없습니다."); return; }
        new AlertDialog.Builder(this)
                .setTitle("저장 메일 전체 삭제")
                .setMessage("로컬 저장 메일 " + count + "건을 모두 삭제합니다. 수집 이력은 유지되므로 같은 메일이 자동으로 다시 들어오지는 않습니다.")
                .setNegativeButton("취소", null)
                .setPositiveButton("전체 삭제", (d, w) -> {
                    int n = db.deleteAll();
                    toast("로컬 저장 " + n + "건 삭제 완료");
                    refreshStatus();
                    renderSavedList();
                })
                .show();
    }

    private void confirmResetCollectionIndex() {
        new AlertDialog.Builder(this)
                .setTitle("수집 이력 초기화")
                .setMessage("자동 수집에서 이미 처리한 메일로 기억한 이력을 지웁니다. 다음 일괄 수집 시 과거 메일이 다시 수집될 수 있습니다. 계속할까요?")
                .setNegativeButton("취소", null)
                .setPositiveButton("초기화", (d, w) -> {
                    int n = db.clearCollectionIndex();
                    toast("수집 이력 " + n + "건 초기화");
                })
                .show();
    }

    private void confirmGptReview(SavedMailRecord r) {
        String[] modes = new String[]{"로컬 요약만 전달", "최신 본문 포함", "취소"};
        new AlertDialog.Builder(this)
                .setTitle("GPT 검토")
                .setMessage("회사 메일 내용이 ChatGPT 앱으로 공유될 수 있습니다. 전달 범위를 선택하세요.")
                .setItems(modes, (d, which) -> {
                    if (which == 0) shareToChatGpt(r, false);
                    else if (which == 1) confirmFullBodyShare(r);
                })
                .show();
    }

    private void confirmFullBodyShare(SavedMailRecord r) {
        new AlertDialog.Builder(this)
                .setTitle("최신 본문 포함")
                .setMessage("선택한 메일의 최신 메시지 구간을 ChatGPT 앱으로 공유합니다. 이전 회신 이력/서명은 가능한 한 제외합니다. 계속할까요?")
                .setNegativeButton("취소", null)
                .setPositiveButton("보내기", (d, w) -> shareToChatGpt(r, true))
                .show();
    }

    private void shareToChatGpt(SavedMailRecord r, boolean includeBody) {
        String prompt = buildGptPrompt(r, includeBody);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, prompt);
        send.setPackage("com.openai.chatgpt");
        try {
            startActivity(send);
        } catch (ActivityNotFoundException e) {
            Intent fallback = new Intent(Intent.ACTION_SEND);
            fallback.setType("text/plain");
            fallback.putExtra(Intent.EXTRA_TEXT, prompt);
            startActivity(Intent.createChooser(fallback, "GPT 검토에 사용할 앱 선택"));
        }
    }

    private String buildGptPrompt(SavedMailRecord r, boolean includeBody) {
        String latest = !r.latestBody.trim().isEmpty() ? r.latestBody : ImportantInfoExtractor.latestMessageBody(r.body);
        latest = sanitizeLatestForGpt(latest);
        if (latest.length() > 8000) latest = latest.substring(0, 8000) + "…";
        StringBuilder b = new StringBuilder();
        b.append("아래 업무 메일을 검토해줘.\n")
                .append("1) 상대방의 핵심 요청과 내가 확인해야 할 사항을 짧게 정리하고,\n")
                .append("2) 원문에 없는 사실은 만들지 말고 불명확한 내용은 [확인 필요]로 표시하고,\n")
                .append("3) 바로 보낼 수 있는 추천 회신 초안을 작성해줘. 상대방 메일 언어를 우선하고 마지막에 한글 요약도 붙여줘.\n\n")
                .append("[Subject] ").append(empty(ImportantInfoExtractor.cleanSubject(r.subject), "(없음)")).append("\n")
                .append("[From] ").append(empty(r.sender, "(미확인)")).append("\n")
                .append("[Date] ").append(empty(r.mailDate, "(미확인)")).append("\n")
                .append("[Local Workflow] ").append(workflowLabel(r.workflowStatus)).append("\n");
        if (!r.keyPoints.trim().isEmpty()) b.append("[Local 핵심 후보] ").append(trim(r.keyPoints, 1200)).append("\n");
        if (!r.actions.trim().isEmpty()) b.append("[Local Action 후보] ").append(trim(r.actions, 900)).append("\n");
        if (!r.schedules.trim().isEmpty()) b.append("[Local 일정 후보] ").append(trim(r.schedules, 500)).append("\n");
        if (includeBody) b.append("\n[Latest Message]\n").append(latest);
        else b.append("\n※ 원문 본문은 전달하지 않았고, 위 로컬 추출 정보만 제공했습니다. 정확한 회신 작성에 원문이 필요하면 필요한 부분을 요청해줘.");
        return b.toString();
    }

    private String sanitizeLatestForGpt(String source) {
        String x = source == null ? "" : source.replace("\r", "").trim();
        x = x.replaceAll("(?i)Caution: External Email\\.?\\s*", "")
                .replaceAll("(?i)Please take care when clicking links or opening attachments\\.?", "")
                .replaceAll("(?i)\\[EXTERNAL\\] This message comes from an external organization\\.[^\\n]*", "")
                .trim();
        String[] boundaries = new String[]{
                "\nThks,", "\nThanks,", "\nThank you,", "\nBest Regards", "\nBest Regard",
                "\n감사합니다.", "\nThe content of this e-mail is confidential", "\n此邮件可能包含机密信息"
        };
        int cut = x.length();
        for (String b : boundaries) {
            int i = x.toLowerCase(Locale.ROOT).indexOf(b.toLowerCase(Locale.ROOT));
            if (i > 40 && i < cut) cut = i;
        }
        return x.substring(0, cut).trim();
    }

    private void showSavedRecord(SavedMailRecord r) {
        currentMail = r.toSnapshot();
        currentInfo = ImportantInfoExtractor.extract(currentMail.subject, currentMail.body);
        bodyExpanded = true;
        renderMail();
        toast("상단 '최근 읽은 메일'에 저장 메일을 불러왔습니다.");
    }

    private String bullets(List<String> list) {
        if (list == null || list.isEmpty()) return "—";
        StringBuilder b = new StringBuilder();
        for (String s : list) {
            if (b.length() > 0) b.append('\n');
            b.append("• ").append(s);
        }
        return b.toString();
    }

    private String firstNonEmptyLine(String s) {
        if (s == null) return "";
        for (String line : s.split("\\n")) if (!line.trim().isEmpty()) return line.trim();
        return "";
    }

    private String formatSavedAt(long ms) {
        if (ms <= 0) return "";
        return new SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(new Date(ms));
    }

    private String trim(String s, int max) {
        if (s == null) return "";
        String x = s.replaceAll("\\s+", " ").trim();
        return x.length() <= max ? x : x.substring(0, max - 1) + "…";
    }

    private String empty(String s, String fallback) { return s == null || s.trim().isEmpty() ? fallback : s.trim(); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
