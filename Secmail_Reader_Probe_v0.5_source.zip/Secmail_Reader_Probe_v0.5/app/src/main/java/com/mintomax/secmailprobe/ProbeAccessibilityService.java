package com.mintomax.secmailprobe;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Explicit-user-start Accessibility collector for Secmail.
 * v0.5 rule: collection is based on whether Secmail Assistant has processed the row,
 * never on Secmail read/unread state.
 */
public class ProbeAccessibilityService extends AccessibilityService {

    public static final String PREFS = "probe_prefs";
    public static final String DEFAULT_TARGET = "com.uusafe.secmail";
    public static final String KEY_TARGET = "target_pkg";
    public static final String KEY_CAPTURE = "last_capture";
    public static final String KEY_CAPTURE_PKG = "last_capture_pkg";
    public static final String KEY_CAPTURE_TIME = "last_capture_time";
    public static final String KEY_NODE_COUNT = "last_node_count";
    public static final String KEY_EVENT = "last_event";
    public static final String KEY_SUBJECT = "mail_subject";
    public static final String KEY_SENDER = "mail_sender";
    public static final String KEY_RECIPIENTS = "mail_recipients";
    public static final String KEY_MAIL_DATE = "mail_date";
    public static final String KEY_BODY = "mail_body";

    public static final String KEY_BATCH_ACTIVE = "batch_active";
    public static final String KEY_BATCH_STATUS = "batch_status";
    public static final String KEY_BATCH_SAVED = "batch_saved";
    public static final String KEY_BATCH_OPENED = "batch_opened";
    public static final String KEY_BATCH_PROCESSED = "batch_processed";
    public static final String KEY_BATCH_SCROLLS = "batch_scrolls";
    public static final String KEY_BATCH_DUPES = "batch_dupes";
    public static final String KEY_BATCH_KNOWN = "batch_known";
    public static final String KEY_BATCH_LAST_FP = "batch_last_fp";
    public static final String KEY_BATCH_PENDING_LIST_SIG = "batch_pending_list_sig";
    public static final String KEY_BATCH_PENDING_PREVIEW = "batch_pending_preview";

    private static final int MAX_NODES = 1000;
    private static final int MAX_CHARS = 260000;
    private static final int MAX_BATCH_OPENED = 50;
    private static final int MAX_BATCH_SCROLLS = 10;
    private static final int STOP_AFTER_KNOWN = 8;

    private long lastCaptureElapsed = 0L;
    private boolean automationBusy = false;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String pkg = event.getPackageName().toString();
        if (!isTargetPackage(pkg)) return;

        long now = SystemClock.elapsedRealtime();
        if (now - lastCaptureElapsed < 300L) return;
        lastCaptureElapsed = now;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        StringBuilder out = new StringBuilder();
        int[] count = new int[]{0};
        walk(root, out, 0, count);

        MailSnapshot mail = extractMail(root);
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault()).format(new Date());
        mail.capturedAt = timestamp;
        mail.packageName = pkg;

        SharedPreferences.Editor e = getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_CAPTURE, out.toString())
                .putString(KEY_CAPTURE_PKG, pkg)
                .putString(KEY_CAPTURE_TIME, timestamp)
                .putInt(KEY_NODE_COUNT, count[0])
                .putString(KEY_EVENT, AccessibilityEvent.eventTypeToString(event.getEventType()));

        if (mail.hasMailContent() && isDetailScreen(root)) {
            e.putString(KEY_SUBJECT, mail.subject)
                    .putString(KEY_SENDER, mail.sender)
                    .putString(KEY_RECIPIENTS, mail.recipients)
                    .putString(KEY_MAIL_DATE, mail.mailDate)
                    .putString(KEY_BODY, mail.body);
        }
        e.apply();

        if (isBatchActive()) handleBatch(root, mail);
    }

    private void handleBatch(AccessibilityNodeInfo root, MailSnapshot mail) {
        if (automationBusy) return;
        SharedPreferences p = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        int opened = p.getInt(KEY_BATCH_OPENED, 0);
        if (opened >= MAX_BATCH_OPENED) {
            stopBatch("완료: 안전 한도 " + MAX_BATCH_OPENED + "개 도달");
            return;
        }

        if (isDetailScreen(root)) {
            handleDetailMail(mail, p);
            return;
        }

        AccessibilityNodeInfo list = findBestInboxList(root);
        if (list == null) {
            AccessibilityNodeInfo inbox = findTextNode(root, new String[]{"받은편지함", "받은 메일함", "Inbox", "收件箱"});
            if (inbox != null && clickClosestClickable(inbox)) {
                automationBusy = true;
                setBatchStatus("Inbox로 이동 중…");
                handler.postDelayed(() -> automationBusy = false, 1100L);
            } else {
                setBatchStatus("Inbox 목록을 찾는 중… · Secmail에서 Inbox를 한 번 열어주세요");
            }
            return;
        }

        List<Candidate> candidates = extractCandidates(list);
        if (candidates.isEmpty()) {
            tryScrollOrFinish(list, p, 0);
            return;
        }

        MailDbHelper db = new MailDbHelper(this);
        Set<String> sessionProcessed = readProcessed();
        int knownThisPage = 0;
        for (Candidate c : candidates) {
            if (sessionProcessed.contains(c.signature)) continue;
            if (db.isCandidateProcessed(c.signature)) {
                db.touchCandidate(c.signature);
                knownThisPage++;
                continue;
            }

            sessionProcessed.add(c.signature);
            writeProcessed(sessionProcessed);
            int nextOpened = p.getInt(KEY_BATCH_OPENED, 0) + 1;
            p.edit()
                    .putInt(KEY_BATCH_OPENED, nextOpened)
                    .putString(KEY_BATCH_PENDING_LIST_SIG, c.signature)
                    .putString(KEY_BATCH_PENDING_PREVIEW, c.preview)
                    .putString(KEY_BATCH_STATUS, "미수집 메일 " + nextOpened + "개째 열기: " + trim(c.preview, 58))
                    .apply();
            if (clickClosestClickable(c.node)) {
                automationBusy = true;
                handler.postDelayed(() -> automationBusy = false, 1300L);
                return;
            }
        }

        int totalKnown = p.getInt(KEY_BATCH_KNOWN, 0) + knownThisPage;
        p.edit().putInt(KEY_BATCH_KNOWN, totalKnown).apply();
        tryScrollOrFinish(list, p, knownThisPage);
    }

    private void handleDetailMail(MailSnapshot mail, SharedPreferences p) {
        if (!mail.looksComplete()) {
            setBatchStatus("메일 본문 로딩 중…");
            return;
        }

        String pendingSig = p.getString(KEY_BATCH_PENDING_LIST_SIG, "");
        String pendingPreview = p.getString(KEY_BATCH_PENDING_PREVIEW, "");
        if (pendingSig.isEmpty()) {
            automationBusy = true;
            setBatchStatus("현재 메일 상세 화면 → Inbox로 이동 중…");
            handler.postDelayed(() -> {
                performGlobalAction(GLOBAL_ACTION_BACK);
                handler.postDelayed(() -> automationBusy = false, 1000L);
            }, 450L);
            return;
        }
        MailDbHelper db = new MailDbHelper(this);
        ImportantInfoExtractor.Result info = ImportantInfoExtractor.extract(mail.subject, mail.body);
        String fp = MailDbHelper.fingerprintFor(mail);

        MailDbHelper.SaveResult sr = db.saveIfNew(mail, info, pendingSig, pendingPreview);
        int saved = p.getInt(KEY_BATCH_SAVED, 0) + (sr.inserted ? 1 : 0);
        int dupes = p.getInt(KEY_BATCH_DUPES, 0) + (sr.duplicate ? 1 : 0);
        String result = sr.inserted ? (sr.threadUpdate ? "Thread 업데이트 저장" : "새 메일 저장") : "기존 메일 확인";
        p.edit()
                .putInt(KEY_BATCH_SAVED, saved)
                .putInt(KEY_BATCH_DUPES, dupes)
                .putString(KEY_BATCH_LAST_FP, fp)
                .putString(KEY_BATCH_PENDING_LIST_SIG, "")
                .putString(KEY_BATCH_PENDING_PREVIEW, "")
                .putString(KEY_BATCH_STATUS, result + " · Inbox로 돌아가는 중…")
                .apply();

        automationBusy = true;
        handler.postDelayed(() -> {
            performGlobalAction(GLOBAL_ACTION_BACK);
            handler.postDelayed(() -> automationBusy = false, 1000L);
        }, 650L);
    }

    private void tryScrollOrFinish(AccessibilityNodeInfo list, SharedPreferences p, int knownThisPage) {
        int scrolls = p.getInt(KEY_BATCH_SCROLLS, 0);
        if (knownThisPage >= STOP_AFTER_KNOWN) {
            stopBatch("완료: 이미 처리한 메일이 연속 " + knownThisPage + "개 확인됨");
            return;
        }
        if (scrolls < MAX_BATCH_SCROLLS && list.isScrollable() && list.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD)) {
            p.edit().putInt(KEY_BATCH_SCROLLS, scrolls + 1).apply();
            automationBusy = true;
            setBatchStatus("다음 Inbox 구간 확인 중… " + (scrolls + 1) + "/" + MAX_BATCH_SCROLLS);
            handler.postDelayed(() -> automationBusy = false, 1100L);
            return;
        }
        stopBatch("완료: 현재 접근 가능한 Inbox의 미수집 메일 확인 종료");
    }

    private boolean isDetailScreen(AccessibilityNodeInfo root) {
        if (root == null) return false;
        boolean body = findByIdRecursive(root, "main-body") != null ||
                findByIdRecursive(root, "mailContentContainer") != null ||
                findByIdRecursive(root, "contentDiv") != null;
        boolean replyUi = findByIdRecursive(root, DEFAULT_TARGET + ":id/quick_reply_bar_input_edittext") != null ||
                findByIdRecursive(root, DEFAULT_TARGET + ":id/titlebar_reply_mail_btn") != null ||
                findByIdRecursive(root, DEFAULT_TARGET + ":id/titlebar_forward_mail_btn") != null;
        return body || replyUi;
    }

    private AccessibilityNodeInfo findBestInboxList(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> lists = new ArrayList<>();
        collectLists(root, lists);
        AccessibilityNodeInfo best = null;
        int bestScore = 0;
        for (AccessibilityNodeInfo n : lists) {
            if (looksLikeDetailContainer(n)) continue;
            List<Candidate> rows = extractCandidates(n);
            if (rows.size() < 2) continue;
            int score = rows.size() * 4;
            String id = safe(n.getViewIdResourceName()).toLowerCase(Locale.ROOT);
            if (id.contains("mail_list") || id.contains("inbox") || id.contains("mail")) score += 6;
            if (n.isScrollable()) score += 3;
            if (score > bestScore) {
                bestScore = score;
                best = n;
            }
        }
        return best;
    }

    private boolean looksLikeDetailContainer(AccessibilityNodeInfo n) {
        return findByIdRecursive(n, "main-body") != null ||
                findByIdRecursive(n, "mailContentContainer") != null ||
                findByIdRecursive(n, DEFAULT_TARGET + ":id/quick_reply_bar_input_edittext") != null ||
                containsClass(n, "android.webkit.WebView");
    }

    private boolean containsClass(AccessibilityNodeInfo node, String className) {
        if (node == null) return false;
        if (safe(node.getClassName()).equals(className)) return true;
        for (int i = 0; i < node.getChildCount(); i++) if (containsClass(node.getChild(i), className)) return true;
        return false;
    }

    private void collectLists(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out) {
        if (node == null) return;
        String cls = safe(node.getClassName());
        if (cls.contains("RecyclerView") || cls.contains("ListView")) out.add(node);
        for (int i = 0; i < node.getChildCount(); i++) collectLists(node.getChild(i), out);
    }

    private static class Candidate {
        final String signature;
        final String preview;
        final AccessibilityNodeInfo node;
        Candidate(String signature, String preview, AccessibilityNodeInfo node) {
            this.signature = signature;
            this.preview = preview;
            this.node = node;
        }
    }

    private List<Candidate> extractCandidates(AccessibilityNodeInfo list) {
        List<Candidate> out = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();
        collectCandidateNodes(list, 0, out, seen);
        return out;
    }

    private void collectCandidateNodes(AccessibilityNodeInfo node, int depth, List<Candidate> out, Set<String> seen) {
        if (node == null || depth > 5 || out.size() >= 30) return;
        if (depth > 0 && node.isClickable() && node.isEnabled()) {
            String compact = collectCompactText(node);
            int score = rowScore(node, compact);
            if (score >= 3) {
                String sig = MailDbHelper.listSignatureFor(compact);
                if (!seen.contains(sig)) {
                    seen.add(sig);
                    out.add(new Candidate(sig, compact, node));
                    return; // Avoid also selecting clickable descendants of the same row.
                }
            }
        }
        for (int i = 0; i < node.getChildCount(); i++) collectCandidateNodes(node.getChild(i), depth + 1, out, seen);
    }

    private int rowScore(AccessibilityNodeInfo node, String compact) {
        if (compact == null) return 0;
        String x = compact.replaceAll("\\s+", " ").trim();
        if (x.length() < 5 || x.length() > 520) return 0;
        String low = x.toLowerCase(Locale.ROOT);
        if (low.equals("reply") || low.equals("forward") || low.contains("전체 회신") ||
                low.contains("caution: external email") || low.contains("the content of this e-mail is confidential")) return 0;

        int score = 1; // clickable + reasonable length
        if (descendantIdContains(node, "subject")) score += 2;
        if (descendantIdContains(node, "sender") || descendantIdContains(node, "from")) score += 2;
        if (descendantIdContains(node, "date") || descendantIdContains(node, "time")) score += 2;
        if (x.matches("(?s).*\\b\\d{1,2}:\\d{2}\\b.*") || x.matches("(?s).*\\b\\d{1,2}/\\d{1,2}\\b.*")) score += 1;
        if (x.length() >= 15 && x.length() <= 320) score += 1;
        return score;
    }

    private boolean descendantIdContains(AccessibilityNodeInfo node, String token) {
        if (node == null) return false;
        String id = safe(node.getViewIdResourceName()).toLowerCase(Locale.ROOT);
        if (id.contains(token)) return true;
        for (int i = 0; i < node.getChildCount(); i++) if (descendantIdContains(node.getChild(i), token)) return true;
        return false;
    }

    private AccessibilityNodeInfo findClickable(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.isClickable() && node.isEnabled()) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo c = findClickable(node.getChild(i));
            if (c != null) return c;
        }
        return null;
    }

    private boolean clickClosestClickable(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo n = node;
        for (int i = 0; i < 6 && n != null; i++) {
            if (n.isClickable() && n.isEnabled()) return n.performAction(AccessibilityNodeInfo.ACTION_CLICK);
            n = n.getParent();
        }
        AccessibilityNodeInfo c = findClickable(node);
        return c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK);
    }

    private AccessibilityNodeInfo findTextNode(AccessibilityNodeInfo node, String[] targets) {
        if (node == null) return null;
        String t = safe(node.getText()).trim();
        for (String target : targets) if (t.equalsIgnoreCase(target)) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo f = findTextNode(node.getChild(i), targets);
            if (f != null) return f;
        }
        return null;
    }

    private Set<String> readProcessed() {
        String raw = getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_BATCH_PROCESSED, "");
        Set<String> s = new LinkedHashSet<>();
        if (raw == null || raw.isEmpty()) return s;
        for (String x : raw.split("\\n")) if (!x.trim().isEmpty()) s.add(x.trim());
        return s;
    }

    private void writeProcessed(Set<String> set) {
        StringBuilder b = new StringBuilder();
        for (String x : set) {
            if (b.length() > 0) b.append('\n');
            b.append(x);
            if (b.length() > 12000) break;
        }
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_BATCH_PROCESSED, b.toString()).apply();
    }

    private boolean isBatchActive() {
        return getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_BATCH_ACTIVE, false);
    }

    private void setBatchStatus(String status) {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_BATCH_STATUS, status).apply();
    }

    private void stopBatch(String reason) {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putBoolean(KEY_BATCH_ACTIVE, false)
                .putString(KEY_BATCH_STATUS, reason)
                .putString(KEY_BATCH_PENDING_LIST_SIG, "")
                .putString(KEY_BATCH_PENDING_PREVIEW, "")
                .apply();
        automationBusy = false;
    }

    private MailSnapshot extractMail(AccessibilityNodeInfo root) {
        MailSnapshot m = new MailSnapshot();
        m.subject = firstTextById(root, DEFAULT_TARGET + ":id/mail_subject_textview");
        m.recipients = firstTextById(root, DEFAULT_TARGET + ":id/to_area_general_tv");
        m.mailDate = firstTextById(root, DEFAULT_TARGET + ":id/mail_date_textview");
        m.sender = findSender(root);

        AccessibilityNodeInfo bodyNode = findByIdRecursive(root, "main-body");
        if (bodyNode == null) bodyNode = findByIdRecursive(root, "mailContentContainer");
        if (bodyNode == null) bodyNode = findByIdRecursive(root, "contentDiv");
        if (bodyNode != null) m.body = collectUsefulText(bodyNode);
        return m;
    }

    private String firstTextById(AccessibilityNodeInfo root, String id) {
        try {
            List<AccessibilityNodeInfo> nodes = root.findAccessibilityNodeInfosByViewId(id);
            if (nodes != null) {
                for (AccessibilityNodeInfo n : nodes) {
                    String t = safe(n.getText()).trim();
                    if (!t.isEmpty()) return t;
                }
            }
        } catch (Exception ignored) {}
        AccessibilityNodeInfo n = findByIdRecursive(root, id);
        return n == null ? "" : safe(n.getText()).trim();
    }

    private String findSender(AccessibilityNodeInfo root) {
        AccessibilityNodeInfo label = findByIdRecursive(root, DEFAULT_TARGET + ":id/mail_sender_name_tv");
        if (label == null) return "";
        AccessibilityNodeInfo parent = label.getParent();
        if (parent == null) return "";
        boolean afterLabel = false;
        for (int i = 0; i < parent.getChildCount(); i++) {
            AccessibilityNodeInfo c = parent.getChild(i);
            if (c == null) continue;
            if (c.equals(label)) { afterLabel = true; continue; }
            if (!afterLabel) continue;
            String id = safe(c.getViewIdResourceName());
            String t = safe(c.getText()).trim();
            if (t.isEmpty()) continue;
            if (id.endsWith("mail_date_textview") || id.endsWith("to_area_general_tv")) continue;
            if (t.equals("발신") || t.equals("발신 ")) continue;
            return t;
        }
        return "";
    }

    private AccessibilityNodeInfo findByIdRecursive(AccessibilityNodeInfo node, String wanted) {
        if (node == null) return null;
        String id = safe(node.getViewIdResourceName());
        if (id.equals(wanted) || id.endsWith(":" + wanted) || id.endsWith("/" + wanted)) return node;
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo found = findByIdRecursive(node.getChild(i), wanted);
            if (found != null) return found;
        }
        return null;
    }

    private String collectUsefulText(AccessibilityNodeInfo node) {
        Set<String> ordered = new LinkedHashSet<>();
        collectText(node, ordered);
        StringBuilder b = new StringBuilder();
        for (String s : ordered) {
            String x = s.replace('\u00A0', ' ').replace("\\n", "\n").trim();
            if (x.isEmpty()) continue;
            if (b.length() > 0) b.append('\n');
            b.append(x);
        }
        return b.toString().trim();
    }

    private String collectCompactText(AccessibilityNodeInfo node) {
        Set<String> ordered = new LinkedHashSet<>();
        collectText(node, ordered);
        StringBuilder b = new StringBuilder();
        for (String s : ordered) {
            String x = s.replace('\u00A0', ' ').replaceAll("\\s+", " ").trim();
            if (x.isEmpty()) continue;
            if (b.length() > 0) b.append(" · ");
            b.append(x);
            if (b.length() > 520) break;
        }
        return b.toString();
    }

    private void collectText(AccessibilityNodeInfo node, Set<String> out) {
        if (node == null) return;
        String t = safe(node.getText()).trim();
        if (!t.isEmpty() && node.getChildCount() == 0) out.add(t);
        for (int i = 0; i < node.getChildCount(); i++) collectText(node.getChild(i), out);
    }

    private boolean isTargetPackage(String pkg) {
        if (getPackageName().equals(pkg)) return false;
        SharedPreferences p = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String target = p.getString(KEY_TARGET, DEFAULT_TARGET);
        if (target != null && !target.trim().isEmpty()) return target.trim().equals(pkg);
        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            String label = pm.getApplicationLabel(ai).toString();
            return label.toLowerCase(Locale.ROOT).contains("secmail");
        } catch (Exception ignored) {
            return false;
        }
    }

    private void walk(AccessibilityNodeInfo node, StringBuilder out, int depth, int[] count) {
        if (node == null || count[0] >= MAX_NODES || out.length() >= MAX_CHARS) return;
        count[0]++;
        String text = safe(node.getText());
        String desc = safe(node.getContentDescription());
        String cls = safe(node.getClassName());
        String id = safe(node.getViewIdResourceName());
        out.append('[').append(count[0]).append("] depth=").append(depth)
                .append(" class=").append(cls)
                .append(" id=").append(id)
                .append(" clickable=").append(node.isClickable())
                .append(" scrollable=").append(node.isScrollable())
                .append(" enabled=").append(node.isEnabled());
        if (!text.isEmpty()) out.append(" text=\"").append(clean(text)).append('"');
        if (!desc.isEmpty()) out.append(" desc=\"").append(clean(desc)).append('"');
        out.append('\n');
        for (int i = 0; i < node.getChildCount(); i++) {
            if (count[0] >= MAX_NODES || out.length() >= MAX_CHARS) break;
            walk(node.getChild(i), out, depth + 1, count);
        }
    }

    private String safe(CharSequence s) { return s == null ? "" : s.toString(); }
    private String clean(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", " ").replace("\n", "\\n");
    }
    private String trim(String s, int max) { return s.length() <= max ? s : s.substring(0, max - 1) + "…"; }

    @Override
    public void onInterrupt() {}
}
