# Secmail Assistant v0.6.1 — Collector Engine + GPT Direct Launch

## v0.6 device finding / root cause
On the tested device v0.6 could discover the Inbox correctly (example: `Inbox 확인 56 · 수집 대상 54`) but remain at `완료 0/54` without reliably opening/capturing each mail.

The code review found two collector-state problems:
1. After scroll/click/back, v0.6 set `automationBusy=true` and relied on a later AccessibilityEvent to continue. Secmail often emitted the useful event while the service was still busy, so that event was discarded and no event remained to advance the state machine.
2. v0.6 marked an Inbox row as session-processed immediately after `ACTION_CLICK` returned true, before confirming that the mail detail screen actually opened. A click that reported success but did not navigate could therefore be silently skipped.

v0.6.1 fixes both behaviors.

## What changed

### 1) Self-continuing collector state machine
- Every scroll / click / Back action now schedules an explicit follow-up read of the current Secmail window.
- Collection no longer depends on Secmail emitting a second AccessibilityEvent after the busy delay.
- If the detail body is still loading, the collector waits and re-checks it automatically.

### 2) Confirm-open-before-processed
- A candidate is **not** marked session-processed just because `ACTION_CLICK` returned true.
- It is marked processed only after the detail screen is captured/saved, or after controlled open retries have failed.
- Failed rows are not written to the persistent `mail_index`, so the next Inbox sync can retry them.

### 3) Conservative open retry
- First attempt: Accessibility `ACTION_CLICK` on the accepted Inbox row/clickable ancestor.
- If Secmail is still on the Inbox list, retry.
- Final fallback: accessibility gesture tap at the accepted row bounds (`canPerformGestures=true`).
- Failure is counted and collection continues instead of hanging.

### 4) Collection limits and progress
- Safety limit raised to 100 opened mails and 20 list-scroll segments so a 50+ mail Inbox can complete in one explicit run.
- UI now shows `열기 실패` count as well as discovered / target / completed / saved counts.
- Read/unread state remains irrelevant; processed/unprocessed remains the collection criterion.

### 5) GPT direct-launch hotfix
- Removed the v0.6 transfer-scope AlertDialog that rendered without selectable items on the tested device/theme.
- Tapping `GPT 검토` / `회신 준비` now directly opens the official ChatGPT Android app with the sanitized latest-message segment and local metadata.
- If ChatGPT is unavailable, Android share chooser is used as fallback.

### 6) GPT conditional web search guidance
- The prompt now tells ChatGPT to use web search only when public external verification is actually needed.
- Search queries must stay at public company / product / technology terms and must not include potentially confidential mail text, internal pricing, capacity, schedules, email addresses or attachment content.
- Output must distinguish `[메일 원문 사실]`, `[웹 확인 사실]` and `[확인 필요]`, and show source / verification timing for web-derived facts.
- This is prompt-driven conditional Search behavior; the Android share intent does not force ChatGPT's Search UI toggle.

### 7) Translation and post-collection workflow retained
- On-device ML Kit translation to Korean remains available for foreign-language latest messages.
- Original body remains authoritative for fingerprint, workflow classification and GPT review.
- Collection continues into Action Inbox: Reply / Action / Schedule / FYI → user action → Waiting / Done.

## Device test checklist
1. Install stable-signed v0.6.1 over stable v0.6.
2. Confirm Accessibility remains ON; if Android disables it after update, enable it once again.
3. Press `Inbox 동기화`.
4. Confirm discovery reaches an Inbox/target count similar to the visible mailbox.
5. Confirm collection then visibly changes from `0/N` to `1/N`, `2/N`… while Secmail mail-detail screens open and return automatically.
6. Confirm `새 저장` increases when a previously unprocessed mail is captured.
7. Confirm a row that cannot open shows an increasing `열기 실패` count and the collector continues to the next row instead of stalling.
8. Let the run finish and confirm the completion overlay offers `Action Inbox` / `결과 보기`.
9. Open an English and a Chinese saved mail and validate Korean auto translation after model availability.
10. Tap `GPT 검토` or `회신 준비` and confirm ChatGPT opens immediately with the selected mail context.

## Known limits
- Exact Secmail Inbox row structure is device/app-version dependent. The collector still uses conservative row scoring/detail-screen guards rather than blind clicking.
- Accessibility collection requires Secmail in foreground; this is not true background mail sync.
- Automatic translation is a reading aid. Technical terms, voltages, process names, dates and commitments must be checked against the original mail.
- Sent-folder based automatic Waiting/Follow-up detection is not included yet.
