# Secmail Reader Probe v0.1

Purpose: verify whether Secmail 3.11.6.4 exposes Inbox / message body text through Android Accessibility.

Scope:
- No INTERNET permission
- No mail-server access
- No OCR or screen capture
- No auto-click or auto-scroll
- Stores only the latest captured accessibility tree in this app's private local storage

Test flow:
1. Install the debug APK.
2. Open Secmail Reader Probe.
3. Open Accessibility settings and enable Secmail Reader Probe.
4. If Android shows a restricted-setting warning for a sideloaded app, follow Android's own security UI; this app does not bypass it.
5. Tap "Secmail 자동 찾기" and confirm a package is found.
6. Tap "Secmail 열기".
7. Open one Inbox message manually in Secmail.
8. Return to Secmail Reader Probe.
9. Tap "결과 불러오기".
10. Check whether sender/subject/body appears as text= or desc= nodes.

Interpretation:
- Body text present: Accessibility-based reader is technically viable.
- Subject only / partial text: hybrid design may be needed.
- No useful text nodes: do not infer content; reassess official protocol/notification route.
