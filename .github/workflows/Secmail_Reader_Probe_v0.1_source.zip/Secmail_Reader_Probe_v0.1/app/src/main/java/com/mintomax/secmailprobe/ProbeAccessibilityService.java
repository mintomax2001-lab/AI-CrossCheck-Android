package com.mintomax.secmailprobe;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ProbeAccessibilityService extends AccessibilityService {

    public static final String PREFS = "probe_prefs";
    public static final String KEY_TARGET = "target_pkg";
    public static final String KEY_CAPTURE = "last_capture";
    public static final String KEY_CAPTURE_PKG = "last_capture_pkg";
    public static final String KEY_CAPTURE_TIME = "last_capture_time";
    public static final String KEY_NODE_COUNT = "last_node_count";
    public static final String KEY_EVENT = "last_event";

    private static final int MAX_NODES = 600;
    private static final int MAX_CHARS = 180000;
    private long lastCaptureElapsed = 0L;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;

        String pkg = event.getPackageName().toString();
        if (!isTargetPackage(pkg)) return;

        long now = SystemClock.elapsedRealtime();
        if (now - lastCaptureElapsed < 450L) return;
        lastCaptureElapsed = now;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        StringBuilder out = new StringBuilder();
        int[] count = new int[]{0};
        walk(root, out, 0, count);

        String timestamp = new SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss.SSS",
                Locale.getDefault()
        ).format(new Date());

        SharedPreferences p = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        p.edit()
                .putString(KEY_CAPTURE, out.toString())
                .putString(KEY_CAPTURE_PKG, pkg)
                .putString(KEY_CAPTURE_TIME, timestamp)
                .putInt(KEY_NODE_COUNT, count[0])
                .putString(KEY_EVENT, AccessibilityEvent.eventTypeToString(event.getEventType()))
                .apply();
    }

    private boolean isTargetPackage(String pkg) {
        SharedPreferences p = getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String target = p.getString(KEY_TARGET, "");
        if (target != null && !target.trim().isEmpty()) {
            return target.trim().equals(pkg);
        }

        try {
            PackageManager pm = getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            String label = pm.getApplicationLabel(ai).toString();
            return label.toLowerCase(Locale.ROOT).contains("secmail");
        } catch (Exception ignored) {
            return false;
        }
    }

    private void walk(AccessibilityNodeInfo node, StringBuilder out, int depth, int[] count) {
        if (node == null) return;
        if (count[0] >= MAX_NODES || out.length() >= MAX_CHARS) return;

        count[0]++;
        String text = safe(node.getText());
        String desc = safe(node.getContentDescription());
        String cls = safe(node.getClassName());
        String id = safe(node.getViewIdResourceName());

        out.append('[').append(count[0]).append("] ")
                .append("depth=").append(depth)
                .append(" class=").append(cls)
                .append(" id=").append(id)
                .append(" clickable=").append(node.isClickable())
                .append(" scrollable=").append(node.isScrollable())
                .append(" enabled=").append(node.isEnabled());

        if (!text.isEmpty()) out.append(" text=\"").append(clean(text)).append('"');
        if (!desc.isEmpty()) out.append(" desc=\"").append(clean(desc)).append('"');
        out.append('\n');

        int n = node.getChildCount();
        for (int i = 0; i < n; i++) {
            if (count[0] >= MAX_NODES || out.length() >= MAX_CHARS) break;
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) walk(child, out, depth + 1, count);
        }
    }

    private String safe(CharSequence s) {
        return s == null ? "" : s.toString();
    }

    private String clean(String s) {
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", " ")
                .replace("\n", "\\n");
    }

    @Override
    public void onInterrupt() {
    }
}
