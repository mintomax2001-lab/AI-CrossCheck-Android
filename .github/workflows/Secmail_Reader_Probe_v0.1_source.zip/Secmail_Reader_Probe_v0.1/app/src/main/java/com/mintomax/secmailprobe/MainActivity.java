package com.mintomax.secmailprobe;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.provider.Settings;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {

    private SharedPreferences prefs;
    private TextView serviceStatus;
    private TextView targetStatus;
    private TextView metaBox;
    private TextView captureBox;
    private EditText targetBox;

    private int dp(int n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(Color.rgb(17, 24, 39));
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setPadding(0, dp(3), 0, dp(6));
        return v;
    }

    private Button button(String label, boolean primary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        if (primary) {
            b.setBackgroundColor(Color.rgb(31, 78, 121));
            b.setTextColor(Color.WHITE);
        }
        return b;
    }

    private LinearLayout section() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(14), dp(12), dp(14), dp(12));
        l.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        lp.setMargins(0, 0, 0, dp(10));
        l.setLayoutParams(lp);
        return l;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(ProbeAccessibilityService.PREFS, Context.MODE_PRIVATE);

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(245, 247, 251));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(18), dp(14), dp(36));
        scroll.addView(root);

        root.addView(text("Secmail Reader Probe", 24, true));
        TextView sub = text("v0.1 · Accessibility UI-tree feasibility test · 외부 전송 없음", 13, false);
        sub.setTextColor(Color.rgb(102, 112, 133));
        root.addView(sub);

        LinearLayout setup = section();
        setup.addView(text("1. Accessibility Service", 17, true));
        serviceStatus = text("", 14, true);
        setup.addView(serviceStatus);
        Button accessibility = button("접근성 설정 열기", true);
        accessibility.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            } catch (Exception e) {
                toast("접근성 설정을 열 수 없습니다.");
            }
        });
        setup.addView(accessibility);
        TextView note = text(
                "설치 출처 때문에 '제한된 설정' 경고가 나오면 Android 보안 안내에 따라 이 앱의 접근성 허용 여부를 직접 결정하세요. 이 Probe는 보안 제한을 우회하지 않습니다.",
                12,
                false
        );
        note.setTextColor(Color.rgb(102, 112, 133));
        setup.addView(note);
        root.addView(setup);

        LinearLayout target = section();
        target.addView(text("2. Secmail Target", 17, true));
        targetStatus = text("", 13, false);
        target.addView(targetStatus);
        targetBox = new EditText(this);
        targetBox.setHint("Secmail package name");
        targetBox.setSingleLine(true);
        targetBox.setText(prefs.getString(ProbeAccessibilityService.KEY_TARGET, ""));
        target.addView(targetBox);

        LinearLayout targetBtns = new LinearLayout(this);
        targetBtns.setOrientation(LinearLayout.HORIZONTAL);
        Button find = button("Secmail 자동 찾기", false);
        Button save = button("Target 저장", false);
        targetBtns.addView(find, new LinearLayout.LayoutParams(0, dp(50), 1f));
        targetBtns.addView(save, new LinearLayout.LayoutParams(0, dp(50), 1f));
        target.addView(targetBtns);
        find.setOnClickListener(v -> discoverSecmail());
        save.setOnClickListener(v -> saveTarget());

        Button open = button("Secmail 열기", true);
        open.setOnClickListener(v -> openSecmail());
        target.addView(open, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(54)
        ));
        root.addView(target);

        LinearLayout result = section();
        result.addView(text("3. Latest Accessibility Capture", 17, true));
        metaBox = text("아직 캡처 없음", 13, false);
        result.addView(metaBox);

        LinearLayout resultBtns = new LinearLayout(this);
        resultBtns.setOrientation(LinearLayout.HORIZONTAL);
        Button reload = button("결과 불러오기", true);
        Button copy = button("복사", false);
        resultBtns.addView(reload, new LinearLayout.LayoutParams(0, dp(50), 1f));
        resultBtns.addView(copy, new LinearLayout.LayoutParams(0, dp(50), 1f));
        result.addView(resultBtns);

        Button clear = button("로컬 캡처 삭제", false);
        result.addView(clear);
        captureBox = text(
                "테스트 순서:\n1) 접근성 서비스 ON\n2) Secmail 자동 찾기\n3) Secmail 열기\n4) Inbox에서 메일 하나 열기\n5) 다시 이 앱으로 돌아오기\n6) 결과 불러오기",
                12,
                false
        );
        captureBox.setTextIsSelectable(true);
        captureBox.setTypeface(Typeface.MONOSPACE);
        captureBox.setBackgroundColor(Color.rgb(248, 250, 252));
        captureBox.setPadding(dp(10), dp(10), dp(10), dp(10));
        result.addView(captureBox);
        reload.setOnClickListener(v -> loadCapture());
        copy.setOnClickListener(v -> copyCapture());
        clear.setOnClickListener(v -> clearCapture());
        root.addView(result);

        LinearLayout scope = section();
        scope.addView(text("Scope", 16, true));
        scope.addView(text(
                "• INTERNET 권한 없음\n• 메일 서버 접속 없음\n• 화면 캡처/OCR 없음\n• 자동 클릭/자동 스크롤 없음\n• 최신 UI-tree 1건만 앱 전용 로컬 저장소에 유지\n• 보안 UI에 노출되지 않는 내용은 읽지 않음",
                12,
                false
        ));
        root.addView(scope);

        setContentView(scroll);
        refreshStatus();
        loadCapture();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void refreshStatus() {
        serviceStatus.setText(isAccessibilityEnabled()
                ? "● ON — Secmail 화면의 접근성 노드를 관찰할 수 있습니다."
                : "○ OFF — 먼저 Secmail Reader Probe 접근성 서비스를 켜세요.");
        String target = prefs.getString(ProbeAccessibilityService.KEY_TARGET, "");
        targetStatus.setText(target == null || target.isEmpty()
                ? "Target package 미설정"
                : "Target: " + target);
    }

    private boolean isAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(
                getContentResolver(),
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        );
        if (TextUtils.isEmpty(enabled)) return false;
        ComponentName cn = new ComponentName(this, ProbeAccessibilityService.class);
        String full = cn.flattenToString();
        String shortName = cn.flattenToShortString();
        TextUtils.SimpleStringSplitter splitter = new TextUtils.SimpleStringSplitter(':');
        splitter.setString(enabled);
        while (splitter.hasNext()) {
            String s = splitter.next();
            if (s.equalsIgnoreCase(full) || s.equalsIgnoreCase(shortName)) return true;
        }
        return false;
    }

    private void discoverSecmail() {
        PackageManager pm = getPackageManager();
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(i, 0);
        ResolveInfo best = null;
        List<String> mailCandidates = new ArrayList<>();

        for (ResolveInfo ri : list) {
            CharSequence loaded = ri.loadLabel(pm);
            String label = loaded == null ? "" : loaded.toString();
            String pkg = ri.activityInfo.packageName;
            String low = label.toLowerCase(Locale.ROOT);
            if (low.equals("secmail") || low.contains("secmail")) {
                best = ri;
                break;
            }
            if (low.contains("mail") || low.contains("메일")) {
                mailCandidates.add(label + " = " + pkg);
            }
        }

        if (best != null) {
            CharSequence loaded = best.loadLabel(pm);
            String label = loaded == null ? "Secmail" : loaded.toString();
            String pkg = best.activityInfo.packageName;
            targetBox.setText(pkg);
            prefs.edit().putString(ProbeAccessibilityService.KEY_TARGET, pkg).apply();
            targetStatus.setText("발견: " + label + "\nPackage: " + pkg);
            toast("Secmail을 찾았습니다.");
            return;
        }

        StringBuilder msg = new StringBuilder("Secmail label을 찾지 못했습니다.");
        if (!mailCandidates.isEmpty()) {
            msg.append("\n\nMail 후보:\n");
            int max = Math.min(8, mailCandidates.size());
            for (int n = 0; n < max; n++) msg.append("• ").append(mailCandidates.get(n)).append('\n');
        }
        targetStatus.setText(msg.toString());
    }

    private void saveTarget() {
        String pkg = targetBox.getText().toString().trim();
        if (pkg.isEmpty()) {
            toast("Package name을 입력하거나 자동 찾기를 실행하세요.");
            return;
        }
        prefs.edit().putString(ProbeAccessibilityService.KEY_TARGET, pkg).apply();
        targetStatus.setText("Target: " + pkg);
        toast("Target 저장 완료");
    }

    private void openSecmail() {
        String pkg = prefs.getString(ProbeAccessibilityService.KEY_TARGET, "");
        if (pkg == null || pkg.trim().isEmpty()) {
            discoverSecmail();
            pkg = prefs.getString(ProbeAccessibilityService.KEY_TARGET, "");
        }
        if (pkg == null || pkg.trim().isEmpty()) {
            toast("Secmail을 먼저 자동 찾기 하세요.");
            return;
        }
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg.trim());
        if (launch == null) {
            toast("Target 앱의 실행 Activity를 찾지 못했습니다.");
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(launch);
    }

    private void loadCapture() {
        String capture = prefs.getString(ProbeAccessibilityService.KEY_CAPTURE, "");
        String pkg = prefs.getString(ProbeAccessibilityService.KEY_CAPTURE_PKG, "");
        String time = prefs.getString(ProbeAccessibilityService.KEY_CAPTURE_TIME, "");
        String event = prefs.getString(ProbeAccessibilityService.KEY_EVENT, "");
        int nodes = prefs.getInt(ProbeAccessibilityService.KEY_NODE_COUNT, 0);
        if (capture == null || capture.isEmpty()) {
            metaBox.setText("아직 Secmail 접근성 캡처가 없습니다.");
            return;
        }
        metaBox.setText("Time: " + time + "\nPackage: " + pkg + "\nEvent: " + event + "\nNodes: " + nodes);
        captureBox.setText(capture);
    }

    private void copyCapture() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        cm.setPrimaryClip(ClipData.newPlainText("Secmail accessibility capture", captureBox.getText().toString()));
        toast("캡처 내용을 클립보드에 복사했습니다.");
    }

    private void clearCapture() {
        prefs.edit()
                .remove(ProbeAccessibilityService.KEY_CAPTURE)
                .remove(ProbeAccessibilityService.KEY_CAPTURE_PKG)
                .remove(ProbeAccessibilityService.KEY_CAPTURE_TIME)
                .remove(ProbeAccessibilityService.KEY_NODE_COUNT)
                .remove(ProbeAccessibilityService.KEY_EVENT)
                .apply();
        metaBox.setText("로컬 캡처 삭제 완료");
        captureBox.setText("");
        toast("삭제했습니다.");
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
